#!/bin/bash

# This script installs the necessary packages for proper application runtime and Python tools using pipx.
# Original commands to be executed:
# sudo apt-get install pipx
# sudo apt-get install apt-transport-https ca-certificates gnupg curl sudo
#
# pipx install numpy --include-deps
# pipx ensurepath
# pipx install rembg --include-deps
# pipx ensurepath
# pipx install rembg[cli] --include-deps --force
# pipx ensurepath
# pipx install ebaysdk --include-deps
# pipx ensurepath
# pipx install ipython --include-deps
# pipx ensurepath
# pipx install image-enhancement --include-deps
# pipx ensurepath
# pipx install imutils --include-deps
# pipx ensurepath
# pipx install pyqt6 --include-deps
# pipx ensurepath

# Update package list and install necessary packages
sudo apt-get update
sudo apt-get install -y pipx
sudo apt-get install -y apt-transport-https ca-certificates gnupg curl sudo

# Install Python packages with pipx
pipx install numpy --include-deps && pipx ensurepath
pipx install rembg --include-deps && pipx ensurepath
pipx install rembg[cli] --include-deps --force && pipx ensurepath
pipx install radian --include-deps && pipx ensurepath
pipx install ebaysdk --include-deps && pipx ensurepath
pipx install ipython --include-deps && pipx ensurepath
pipx install image-enhancement --include-deps && pipx ensurepath
pipx install imutils --include-deps && pipx ensurepath
pipx install pyqt6 --include-deps && pipx ensurepath

# Ensure pipx path is added to shell
pipx ensurepath

# Pause for user input
echo ""
echo "The automatic dependancy installer script has executed. Please feel free to check the console log to see if there were any odd behaviors during installation. Press return to end the script, or close the terminal window."
read