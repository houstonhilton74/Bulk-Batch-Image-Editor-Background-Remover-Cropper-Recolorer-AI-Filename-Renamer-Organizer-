def generateAndVerifyFilePermutations(baseFileName):
	
	fileNameCombinations = []
	
	baseFileName = baseFileName.replace(".jpg", "") #clearing given file name of any extensions. The suffix will be used as the basename beginning all possible filename variations/permutations.
	baseFileName = baseFileName.replace(".jpeg", "")
	baseFileName = baseFileName.replace(".JPG", "")
	baseFileName = baseFileName.replace(".JPEG", "")
	baseFileName = baseFileName.replace(".PNG", "")
	baseFileName = baseFileName.replace(".png", "")
	
	# Given specific items and file extensions
	specific_items = ["_RECOLORED", "_BGREMOVED", "_CROPPED", "_metadata"]
	file_extensions = [".png", ".jpeg", ".JPEG", ".jpg", ".JPG", ".PNG", ".txt"]

	# Initialize a set to store unique combinations
	unique_combinations = set()

	# Generate permutations with the longest possible length first to the shortest last
	for i in range(len(specific_items), 0, -1):
		specific_permutations = permutations(specific_items, i)
		for specific_permutation in specific_permutations:
			remaining_extensions = [ext for ext in file_extensions if ext not in specific_permutation]
			if remaining_extensions:
				for extension in remaining_extensions:
					combined_perm = specific_permutation + (extension,)
					sorted_permutation = tuple(sorted(combined_perm, key=lambda x: specific_items.index(x) if x in specific_items else float('inf')))
					unique_combinations.add(str(baseFileName) + ''.join(sorted_permutation))

	# Sort the unique combinations by length (shortest first, longest last)
	sorted_combinations = sorted(unique_combinations, key=len, reverse=True)

	# Build all sorted combinations into an array to be used for cross-checking the file history text file later...
	for combination in sorted_combinations:
		fileNameCombinations.append(combination)
	
	i = 0 #Setting an iterator for some iterative operations...
	
	while(i < len(fileNameCombinations)):
		fileChain = find_text_in_file(fileHistoryFileFullPath, fileNameCombinations[i]) #try to find and generate any file chain(s) that contain the filename variant.
		if (fileChain == []):
			print("NO EQUIVALENT FILE CHAIN FOUND FOR FILE PERMUTATION: " + str(fileNameCombinations[i]) + " IN FILE HISTORY TEXT FILE.")
		else:
			print("FILE CHAIN FOUND FOR FILE PERMUTATION " + str(fileNameCombinations[i]) + ". Chain: " + str(fileChain))
		i += 1