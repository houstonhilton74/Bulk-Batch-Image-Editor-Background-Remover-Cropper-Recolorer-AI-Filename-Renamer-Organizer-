#programmer reference#
#Image.crop(left, top, right, bottom) #cropping command
#arr = img.load()
#arr[20, 30] # tuple of 4 ints
#if maskColor == arr[1100,1800]:
#	print("Pixel samples match!")
#else:
#	print("Pixel samples DO NOT match!")
#programmer reference#

#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
import linecache
#importing libraries and so forth#

#variable initializations#
invalidImage = False #triggers if an image was found to have no content in it to crop around
maskColor = (255, 255, 255, 255) #color pixel configuration object that will be used as a defining the image mask. Any pixel color that is NOT this exact color configuration may trigger an image cropping boundary! Don't forget to add alpha channel for white!
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
######
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
######
#sourceImageFileName = input_data_folder / "DUMMYFILEDONOTREMOVE.png"
leftHandImageBoundary = 0 #image boundary - this will be designed as cutoff points for the image during the cropping process.
rightHandImageBoundary = 0 #image boundary - this will be designed as cutoff points for the image during the cropping process.
topImageBoundary = 0 #image boundary - this will be designed as cutoff points for the image during the cropping process.
bottomImageBoundary = 0 #image boundary - this will be designed as cutoff points for the image during the cropping process.
iX = 0 #iterator for control loops X axis
iY = 0 #iterator for control loops Y axis
fileCountInput = 0 #file counter for how many files are in input directory
i = 0 #generic iterator
#variable initializations#


#function definitions
def getBoundaries(sourceImage): #function that gets cutoff points for image in preparation for its cropping.
	#print('Getting image boundaries...')
	invalidImage = False
	iX = 0
	iY = 0
	leftHandImageBoundary = 0
	rightHandImageBoundary = 0
	topImageBoundary = 0
	bottomImageBoundary = 0
	img = Image.open(sourceImage)
	arr = img.load()
	imageWidth, imageHeight = img.size
	
	while maskColor == arr[iX, iY] and invalidImage == False: #top boundary detector. Starts from the top most row and works its way from left to right, then goes down row by row.
		if iX == imageWidth - 2 and iY == imageHeight - 2: #Special case if statement that invalidates image if it already went through all rows and columns of pixels and couldn't find any content.
			invalidImage = True
		if iX < imageWidth:
			iX = iX + 1
		if iX >= imageWidth:
			iX = 0
			iY = iY + 1
		
	topImageBoundary = iY
	#print('Top Image Boundary: ')
	#print(topImageBoundary) 
	#end of top
	
	iY = imageHeight - 1
	iX = 0
	
	while maskColor == arr[iX, iY]and invalidImage == False: #bottom boundary detector. Starts from the bottom most row and works its way from left to right, then goes up row by row.
		if iX < imageWidth:
			iX = iX + 1
		if iX >= imageWidth:
			iX = 0
			iY = iY - 1
	 
	bottomImageBoundary = iY
	#print('Bottom Image Boundary: ')
	#print(bottomImageBoundary) 
	#end of Bottom
	
	iY = 0
	iX = 0
	
	while maskColor == arr[iX, iY] and invalidImage == False: #left boundary detector. Starts from the left most column and works its way from top to bottom, then goes to the right column by column.
		if iY < imageHeight:
			iY = iY + 1
		if iY >= imageHeight:
			iY = 0
			iX = iX + 1
	 
	leftHandImageBoundary = iX
	#print('Left Hand Image Boundary: ')
	#print(leftHandImageBoundary) 
	#end of left
	
	iY = 0
	iX = imageWidth - 1
	
	while maskColor == arr[iX, iY] and invalidImage == False: #right boundary detector. Starts from the right most column and works its way from top to bottom, then goes to the left column by column.
		if iY < imageHeight:
			iY = iY + 1
		if iY >= imageHeight:
			iY = 0
			iX = iX - 1
	 
	rightHandImageBoundary = iX
	#print('Right Hand Image Boundary: ')
	#print(rightHandImageBoundary) 
	#end of right
	
	if invalidImage == True:
		print('No content was found in this image. If this appears incorrect, please check the specific mask coloring that was specified in the script variable - including the alpha channel. Cropping will be ignored on this file.')
		return 0, 0, 0, 0, invalidImage
	
	return leftHandImageBoundary, rightHandImageBoundary, topImageBoundary, bottomImageBoundary, invalidImage #return boundary variables that crop function will use

def cropImage(sourceImage, iteration, fileTotal, historyLineNumber): #image cropping function based off of defined cutoff points/boundaries
	left, right, top, bottom, imageInvalid = getBoundaries(sourceImage)
	if imageInvalid == False:
		img = Image.open(sourceImage)
		img_res = img.crop((left, top, right, bottom))
		fileNameIteration = str(iteration)
		fileTotalString = str(fileTotal)
		frontEndIteration = int(iteration) + 1 #this is a dummy iteration value offset by 1 to look pretty for the end user only. It has no practical purpose in backend processing.
		frontEndIterationRealFrontEnd = str(frontEndIteration)
		print('Outputting file ' + frontEndIterationRealFrontEnd + ' of ' + fileTotalString + '.')
		#img_res.save(output_data_folder / frontEndIterationRealFrontEnd,"PNG")
		sourceImageToString = str(os.path.basename(sourceImage))
		
		tempFileExtension = "FILLER"
		tempFileExtension = os.path.splitext(str(sourceImage))[-1].lower() #getting file extension so that it can be explicitly added on the filename later...
		sourceImageToString = sourceImageToString.replace(".PNG", "")
		sourceImageToString = sourceImageToString.replace(".png", "")
		sourceImageToString = sourceImageToString.replace(".JPG", "")
		sourceImageToString = sourceImageToString.replace(".jpg", "")
		sourceImageToString = sourceImageToString.replace(".JPEG", "")
		sourceImageToString = sourceImageToString.replace(".jpeg", "") #temporarily removing file extension so that "_CROPPED" can be added into the file name itself
		sourceImageToString = sourceImageToString + "_CROPPED"
		sourceImageToString = sourceImageToString + str(tempFileExtension) #adding back in file explicit file extension
		print(sourceImageToString)
		
		if "exif" in img.info: #checking for exif data to see if it needs to be preserved at save or not. The color adjuster, for example, strips all EXIF data which would otherwise cause runtime issues without the conditional statement.
			if(tempFileExtension == '.PNG' or tempFileExtension == '.png'):
				img_res.save(output_data_folder / sourceImageToString,"PNG",exif=img.info.get('exif'))
			if(tempFileExtension == '.jpg' or tempFileExtension == '.JPG' or tempFileExtension == '.jpeg' or tempFileExtension == '.JPEG'): #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
				img_res.save(output_data_folder / sourceImageToString,"JPEG",exif=img.info.get('exif')) #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
		else:
			if(tempFileExtension == '.PNG' or tempFileExtension == '.png'):
				img_res.save(output_data_folder / sourceImageToString,"PNG")
			if(tempFileExtension == '.jpg' or tempFileExtension == '.JPG' or tempFileExtension == '.jpeg' or tempFileExtension == '.JPEG'): #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
				img_res.save(output_data_folder / sourceImageToString,"JPEG") #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
		
		######
		baseOutputFile = str(sourceImageToString) #generating the outputted file name so that it can be recorded into the file history text file...
		fileHistoryOutputFile(baseOutputFile, historyLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
		######
		
######
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {AUTOCROPPED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
######

#function definitions

#imperative commands#
print('Starting automatic cropping...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #begin batch image crop batch cycle here
	sourceImageFileName = input_data_folder / filesList[i] #adjusting source image filename for each iteration
	######
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	######
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	img = Image.open(sourceImageFileName)
	arr = img.load() #source image array
	imageWidth, imageHeight = img.size #source image dimensions
	cropImage(sourceImageFileName, i, file_count, fileHistoryTextLineNumber)
	i = i + 1
	

#input("Press Enter to continue.")
#imperative commands#


