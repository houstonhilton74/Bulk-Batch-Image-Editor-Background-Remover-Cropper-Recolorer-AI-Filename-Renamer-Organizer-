#programmer reference#

#programmer reference#


#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os.path import exists
from os import listdir
from os.path import isfile, join
import fnmatch
import shutil
import time
import linecache
from itertools import combinations

#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Output_Directory/" #Consolidator local output directory
cacheFolder = Path(__file__).parent / "./tempCache/" #directory used to temporarily store renamed original image files as they are renamed during processing.
input_data_folder = Path(__file__).parent / "./Input_Directory/" #Consolidator local input directory
main_input_folder = Path(__file__).parent.parent.parent / "./Master_Input_Folder/" #path to master/main image input folder. This path is needed for copying the old image file names into the appropriate folders...
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
i = 0 #generic iterator

#variable initializations#


#function definitions
def consolidateFile(inputtedFilenameandPath): #Catch-all file consolidator. The idea is to align all generated tracking arrays below and copy the files into their respective generated folders. It does this based on data from the file history text file.
	basenameInputtedFile = str(os.path.basename(inputtedFilenameandPath))
	print("Consolidating relevant files for inputted image " + basenameInputtedFile + "...")
	
	with open(fileHistoryFileFullPath, 'r') as file: #Get number of lines from file history text file to determine if it is effectively empty or not...
		lines = file.readlines()
		line_count = len(lines)
		file.close()

	if line_count == 1: #if the line count is one, that means that there was no file history generated, so we'll just copy all original files, rename them with the _ORIGINAL tag at the end, make folders of their filenames, and copy them over into the local output folder and into each folder matching their filename, excluding the _ORIGINAL tag.
		shutil.copy2(str(inputtedFilenameandPath), str(cacheFolder)) #copying original no-name change image from main input to temporary cache folder...
		
		basenameInputtedFile = str(os.path.basename(inputtedFilenameandPath)) #get base name of newly copied name unchanged file...
		
		index = str(basenameInputtedFile).find(".") #renaming original file to the same name but with the string, "_ORIGINAL" tacked onto the end of it - right before the period used to define the file extension. Please note that the original file will temporarily be copied to a cache folder in the consolidator program directory before it is ultimately put into the correct output subfolder.
		renamedOriginalFileName = basenameInputtedFile[:index] + "_ORIGINAL" + basenameInputtedFile[index:] #generating updated original image file name as string
		cacheOriginalFileNameandDir = str(cacheFolder) + "/" + str(renamedOriginalFileName) #defining new temporary file save path with renaming...
		os.rename(str(cacheFolder) + "/" + basenameInputtedFile, cacheOriginalFileNameandDir) #renaming actual file in cache folder to the _ORIGINAL tag equivalent...
		
		officialTitle = str(basenameInputtedFile) #generating and cleaning up inputted image file(s) to prepare folder title...
		officialTitle = officialTitle.replace("_", " ") #cleaning up image file name to something presentable for folder generation...
		officialTitle = officialTitle.replace(".jpg", "")
		officialTitle = officialTitle.replace(".jpeg", "")
		officialTitle = officialTitle.replace(".JPG", "")
		officialTitle = officialTitle.replace(".JPEG", "")
		officialTitle = officialTitle.replace(".PNG", "")
		officialTitle = officialTitle.replace(".png", "")
		officialTitle = officialTitle.replace("\n", "")
		
		subfolder_path = os.path.join(output_data_folder, str(officialTitle)) #generating new subfolder in local output folder based on its cleaned up title...
		os.mkdir(subfolder_path)
		
		shutil.copy2(str(cacheFolder) + "/" + str(renamedOriginalFileName), str(subfolder_path)) #copying renamed original image equivalent from cache folder to proper subfolder in output folder...
		
	#otherwise, we'll proceed with more specific consolidation operation if at least one image operation occurred during the course of the program.	
	else:		
		basenameInputtedFile = str(os.path.basename(inputtedFilenameandPath)) #get base name of newly copied name unchanged file...
		matchingTextLinesArray = find_text_in_file(fileHistoryFileFullPath, basenameInputtedFile) #Getting matching line numbers that contain the basename the original inputted file file name (from the main input. Not to be confused with local input folder)...
		theoreticalFileToBeCopied = "NULL" #placeholder for changing name of file to be copied in the future...
		theoreticalFileToBeCopied = str(basenameInputtedFile) #Theoretical file to be copied is the same name as the original inputted file at this point, before potential changes occur - if they do, that is. Otherwise this will be the name.
		aiRenamedBaseFileName = "NULL" #This is a placeholder for a file basename for IF and ONLY IF an AI Renamer was used in the configuration. It will serve as the base file "stem" for all possible file permutations of it when fed into the permutation generator.
		
		i = 0 #generic iterator...
		
		with open(fileHistoryFileFullPath, 'r') as file: #get lines from file history text file for parsing...
			lines = file.readlines()
				
		fileCandidates = generatePossibleFilePermutations(basenameInputtedFile) #Generate all possible permutations for files using the ORIGINAL filename in the main input folder (where no AI renaming was used; We'll add on more permutations later if AI was actually called.)
		
		#print("Matching Text Line Numbers in File History Text File for " + str(basenameInputtedFile) + ": " + str(matchingTextLinesArray))
		
		while(i < len(fileCandidates)): #checking file history text file to see if any of the lines that any of the "original" file name permutations show evidence that AIRenaming was used...  
			textLinesArray = find_text_in_file(fileHistoryFileFullPath, str(fileCandidates[i]))
			
			if textLinesArray != []:
				#print("Yay! File Candidate " + str(fileCandidates[i]) + " was found in the following text file line(s): " + str(textLinesArray))
				iN = 0 #nested iterator to check each line in the matching text line array of lines where "original" permutation was found to see if they have evidence of AIrenaming in them.
				while(iN < len(textLinesArray)):
					line = linecache.getline(str(fileHistoryFileFullPath), textLinesArray[iN])
					if line != '':
						line = line.strip()  # Strip newline characters
					
					line = str(line)
					
					if line.find("{AIRENAMED}") != -1: #if evidence of renaming was found in the text line...
						#print("String with " + str(fileCandidates[i]) + " in it at file history text line " + str(textLinesArray[iN]) + " contains '{AIRENAMED}'. Evidence of AI Renaming found.")
						tempArray = line.split(" -> ")
						found_element = str(next((element for element in tempArray if "{AIRENAMED}" in element), None)) #find first list item containing "{AIRenamed}" in temporary array data structure that was generated by splitting up the text line string by the " -> " delimiter. 
						found_element = found_element.replace("{AIRENAMED}", "")
						found_element = found_element.replace("_CROPPED", "") #cleaning up detected AIRenamed filename so that it is only the "stem" name.
						found_element = found_element.replace("_REPIXELATED", "")
						found_element = found_element.replace("_BGREMOVED", "")
						found_element = found_element.replace("\n", "")
						found_element = found_element.split(".")[0] #getting rid of any file extension...
						#print("CLEANED UP AI RENAMED STEM NAME: " + str(found_element))
						aiRenamedBaseFileName = str(found_element) #change the AI renamed basename to something OTHER than "NULL," as that will be used later to generate a set of relevant permutations
					#else:
						#print("String with " + str(fileCandidates[i]) + " in it at file history text line " + str(textLinesArray[iN]) + " shows no evidence of AI Renaming.")						
					iN = iN + 1
				
					#else:
						#print("File Candidate " + str(fileCandidates[i]) + " was NOT found anywhere in the history text file.")
			
			i = i + 1
		
		i = 0
		
		if aiRenamedBaseFileName != "NULL":
			fileCandidates = fileCandidates + generatePossibleFilePermutations(aiRenamedBaseFileName) #if AI renamed basename was found previously in the text history file for the given main inputted file, generate a new set of possible filename permutations and attach it to the end of the already existing file candidate permutations.
			theoreticalFileToBeCopied = str(aiRenamedBaseFileName) #preparation folder creation portion. It will change it to the AI Renamed "Stem" name if AI Renaming Occurred...
		
		#print("Possible File Candidates to be Copied: " + str(fileCandidates))
		
		officialTitle = str(theoreticalFileToBeCopied) #cleaning up image file name to something presentable for folder generation...
		officialTitle = officialTitle.replace("_CROPPED", "")
		officialTitle = officialTitle.replace("_REPIXELATED", "")
		officialTitle = officialTitle.replace("_BGREMOVED", "")
		officialTitle = officialTitle.replace("_", " ") 
		officialTitle = officialTitle.replace(".jpg", "")
		officialTitle = officialTitle.replace(".jpeg", "")
		officialTitle = officialTitle.replace(".JPG", "")
		officialTitle = officialTitle.replace(".JPEG", "")
		officialTitle = officialTitle.replace(".PNG", "")
		officialTitle = officialTitle.replace(".png", "")
		officialTitle = officialTitle.replace("\n", "")

		
		local_output_path = os.path.join(output_data_folder, str(officialTitle)) #generating new subfolder in local output folder based on its cleaned up title...
		os.mkdir(local_output_path)
		
		i = 0
		
		while(i < len(fileCandidates)): #check through all possible file permutation/variations for the current main inputted file and copy the file over from the LOCAL input directory to the local output directory equivalent if it exists...
			fileCandidateInputFolderPath = str(input_data_folder) + "/" + str(fileCandidates[i]) #generate hypothetical LOCAL input folder path for each possible file candidate/permutation...
			if Path(fileCandidateInputFolderPath).exists():
				#print(f"The file '{fileCandidateInputFolderPath}' exists.")
				shutil.copy2(fileCandidateInputFolderPath, str(local_output_path)) #copy existing file candidate from LOCAL input folder path to local output folder path equivalent...
			#else:
				#print(f"The file '{fileCandidateInputFolderPath}' does not exist.")
				
			i = i + 1
		
		i = 0
		
		while(i < len(fileCandidates)): #check through all possible file permutation/variations for the current main inputted file and copy the file over from the MAIN input directory to the local output directory equivalent if it exists...
			fileCandidateInputFolderPath = str(main_input_folder) + "/" + str(fileCandidates[i]) #generate hypothetical MAIN input folder path for each possible file candidate/permutation...
			if Path(fileCandidateInputFolderPath).exists():
				#print(f"The file '{fileCandidateInputFolderPath}' exists.")
				shutil.copy2(fileCandidateInputFolderPath, str(local_output_path)) #copy existing file candidate from MAIN input folder path to local output folder path equivalent...
				
				index = str(fileCandidates[i]).find(".") #renaming original file to the same name but with the string, "_ORIGINAL" tacked onto the end of it - right before the period used to define the file extension. Please note that the original file will temporarily be copied to a cache folder in the consolidator program directory before it is ultimately put into the correct output subfolder.
				renamedFileName = fileCandidates[i][:index] + "_ORIGINAL" + fileCandidates[i][index:] #generating updated original image file name as string
				
				renamedFileNameandDir = str(local_output_path) + "/" + str(renamedFileName) #defining the location of file to be renamed. It will be in the same location regardless...
				os.rename(str(local_output_path) + "/" + fileCandidates[i], renamedFileNameandDir) #renaming actual file in cache folder to the _ORIGINAL tag equivalent...
				
			#else:
				#print(f"The file '{fileCandidateInputFolderPath}' does not exist.")
				
			i = i + 1
		
		i = 0
		
		file.close()
		
def find_text_in_file(file_path, search_text): #Text file searcher searches for a key word and then returns an array of all the line numbers where it was found.
	matchingTextLines_Array = [] #array to carry any possible matching text lines from base filename query...
	with open(file_path, 'r') as file:
		for line_number, line in enumerate(file, start=1):
			if search_text in line:
				matchingTextLines_Array.append(line_number)

	return matchingTextLines_Array

def generatePossibleFilePermutations(baseFileName):
	possibleFileNameCombinations = [] #all possible file permutations with this program's file naming system...
	file_Candidates = [] #likely file candidates that actually exist. These are file names that were found in the file history text file but do not necessarily mean that they exist in the consolidator's input folder. They're like educated guesses.	
	
	baseFileName = baseFileName.split(".")[0]  # Clearing given file name of any extensions. Notice that the base name will either be the AI renamed equivalent or original if no AIRENAMING was detected.
	baseFileName = baseFileName.replace("\n", "")
	
	# Given specific items and file extensions
	specific_items = ["_REPIXELATED", "_BGREMOVED", "_CROPPED", "_metadata"]
	file_extensions = [".png", ".jpeg", ".JPEG", ".jpg", ".JPG", ".PNG", ".txt"]
	
	# Initialize a set to store unique combinations
	unique_combinations = set()
	
	# Generate combinations allowing specific_items to be omitted
	for i in range(len(specific_items) + 1):
		specific_combinations = combinations(specific_items, i)
		for specific_combination in specific_combinations:
			remaining_extensions = [ext for ext in file_extensions if ext not in specific_combination]
			if remaining_extensions:
				for extension in remaining_extensions:
					combined_perm = specific_combination + (extension,)
					sorted_permutation = tuple(sorted(combined_perm, key=lambda x: specific_items.index(x) if x in specific_items else float('inf')))
					unique_combinations.add(str(baseFileName) + ''.join(sorted_permutation))
	
	# Sort the unique combinations by length (shortest first, longest last)
	sorted_combinations = sorted(unique_combinations, key=len, reverse=True)
	
	# Build all sorted combinations into an array to be used for cross-checking the file history text file later...
	for combination in sorted_combinations:
		possibleFileNameCombinations.append(combination)
	
	file_Candidates = possibleFileNameCombinations 	
	
	return file_Candidates

#function definitions


#imperative commands#
print('Consolidating edited images and their metadata file equivalents (if present) into folders in the consolidator output folder...')

_, _, files = next(os.walk(main_input_folder)) #counting files in main input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the main input directory...

filesList = [f for f in listdir(main_input_folder) if isfile(join(main_input_folder, f))] #parsing file manifest list for main input folder...

while i < file_count: #begin batch image crop batch cycle here
	sourceImageFileName = main_input_folder / filesList[i] #adjusting source image filename from main input folder for each iteration...
	
	consolidateFile(sourceImageFileName)
	
	i = i + 1
#imperative commands#


