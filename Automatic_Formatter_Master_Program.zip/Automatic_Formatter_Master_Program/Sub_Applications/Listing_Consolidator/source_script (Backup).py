#programmer reference#

#programmer reference#


#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os.path import exists
from os import listdir
from os.path import isfile, join
import fnmatch
import shutil
import time
import linecache

#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Output_Directory/" #Consolidator local output directory
cacheFolder = Path(__file__).parent / "./tempCache/" #directory used to temporarily store renamed original image files as they are renamed during processing.
input_data_folder = Path(__file__).parent / "./Input_Directory/" #Consolidator local input directory
main_input_folder = Path(__file__).parent.parent.parent / "./Master_Input_Folder/" #path to master/main image input folder. This path is needed for copying the old image file names into the appropriate folders...
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
i = 0 #generic iterator

#variable initializations#


#function definitions
def consolidateFile(inputtedFilenameandPath): #Catch-all file consolidator. The idea is to align all generated tracking arrays below and copy the files into their respective generated folders. It does this based on data from the file history text file.

	with open(fileHistoryFileFullPath, 'r') as file: #Get number of lines from file history text file to determine if it is effectively empty or not...
		lines = file.readlines()
		line_count = len(lines)
		file.close()

	if line_count == 1: #if the line count is one, that means that there was no file history generated, so we'll just copy all original files, rename them with the _ORIGINAL tag at the end, make folders of their filenames, and copy them over into the local output folder and into each folder matching their filename, excluding the _ORIGINAL tag.
		shutil.copy2(str(inputtedFilenameandPath), str(cacheFolder)) #copying original no-name change image from main input to temporary cache folder...
		
		basenameInputtedFile = str(os.path.basename(inputtedFilenameandPath)) #get base name of newly copied name unchanged file...
		
		index = str(basenameInputtedFile).find(".") #renaming original file to the same name but with the string, "_ORIGINAL" tacked onto the end of it - right before the period used to define the file extension. Please note that the original file will temporarily be copied to a cache folder in the consolidator program directory before it is ultimately put into the correct output subfolder.
		renamedOriginalFileName = basenameInputtedFile[:index] + "_ORIGINAL" + basenameInputtedFile[index:] #generating updated original image file name as string
		cacheOriginalFileNameandDir = str(cacheFolder) + "/" + str(renamedOriginalFileName) #defining new temporary file save path with renaming...
		os.rename(str(cacheFolder) + "/" + basenameInputtedFile, cacheOriginalFileNameandDir) #renaming actual file in cache folder to the _ORIGINAL tag equivalent...
		
		officialTitle = str(basenameInputtedFile) #generating and cleaning up inputted image file(s) to prepare folder title...
		officialTitle = officialTitle.replace("_", " ") #cleaning up image file name to something presentable for folder generation...
		officialTitle = officialTitle.replace(".jpg", "")
		officialTitle = officialTitle.replace(".jpeg", "")
		officialTitle = officialTitle.replace(".JPG", "")
		officialTitle = officialTitle.replace(".JPEG", "")
		officialTitle = officialTitle.replace(".PNG", "")
		officialTitle = officialTitle.replace(".png", "")
		
		subfolder_path = os.path.join(output_data_folder, str(officialTitle)) #generating new subfolder in local output folder based on its cleaned up title...
		os.mkdir(subfolder_path)
		
		shutil.copy2(str(cacheFolder) + "/" + str(renamedOriginalFileName), str(subfolder_path)) #copying renamed original image equivalent from cache folder to proper subfolder in output folder...
		
	#otherwise, we'll proceed with more specific consolidation operation if at least one image operation occurred during the course of the program.	
	else:
		shutil.copy2(str(inputtedFilenameandPath), str(cacheFolder)) #copying original no-name change image from main input to temporary cache folder...
		
		basenameInputtedFile = str(os.path.basename(inputtedFilenameandPath)) #get base name of newly copied name unchanged file...
		
		index = str(basenameInputtedFile).find(".") #renaming original file to the same name but with the string, "_ORIGINAL" tacked onto the end of it - right before the period used to define the file extension. Please note that the original file will temporarily be copied to a cache folder in the consolidator program directory before it is ultimately put into the correct output subfolder.
		renamedOriginalFileName = basenameInputtedFile[:index] + "_ORIGINAL" + basenameInputtedFile[index:] #generating updated original image file name as string
		cacheOriginalFileNameandDir = str(cacheFolder) + "/" + str(renamedOriginalFileName) #defining new temporary file save path with renaming...
		os.rename(str(cacheFolder) + "/" + basenameInputtedFile, cacheOriginalFileNameandDir) #renaming actual file in cache folder to the _ORIGINAL tag equivalent...
		
		matchingTextLinesArray = find_text_in_file(fileHistoryFileFullPath, basenameInputtedFile) #Getting matching line numbers that contain the basename the original inputted file file name...
		theoreticalFileToBeCopied = "NULL" #placeholder for changing name of file to be copied in the future...
		theoreticalFileToBeCopied = str(basenameInputtedFile) #Theoretical file to be copied is the same name as the original inputted file at this point, before potential changes occur - if they do, that is. Otherwise this will be the name.
		
		aiRenameTrigger = False #Boolean value to determine if AI renaming was used. It will come in handy when dealing with determining the correct metadata text file to copy over and consolidate if applicable and when the time calls for it...
		
		i = 0 #generic iterator...
		
		with open(fileHistoryFileFullPath, 'r') as file: #get lines from file history text file for parsing...
			lines = file.readlines()
		
		###
		
		while (i < len(matchingTextLinesArray)): #this while loop is intended to look and see if any image recoloring had occurred, as well as change the hypothetical filename that will be copied, assuming no other operations occur...
			
			if "{COLORADJUSTED}" in lines[matchingTextLinesArray[i] - 1]: #Check all line numbers in array for any lines that have {AI Renamed} in them...
				tempArray = str(lines[matchingTextLinesArray[i] - 1]).split(" -> ") #splitting up text in matching line of file to a temporary array to get the correct RECOLORED filename...
				matches = [element for element in tempArray if "{COLORADJUSTED}" in element] # Using list comprehension to find elements that contain "{COLORADJUSTED}"
				for match in matches:
					tempString = str(match)
					tempString = tempString.replace("{COLORADJUSTED}","") #Cleaning up filename to what it would appropriately be called when copied, theoretically... assuming no other operations were performed at this point.
					theoreticalFileToBeCopied = tempString
			i = i + 1

		i = 0
		
		###
		
		while (i < len(matchingTextLinesArray)): #this while loop is intended to look and see if any AI renaming had occurred, as well as change the hypothetical filename that will be copied, assuming no other operations occur...
			
			if "{AIRENAMED}" in lines[matchingTextLinesArray[i] - 1]: #Check all line numbers in array for any lines that have {AI Renamed} in them...
				tempArray = str(lines[matchingTextLinesArray[i] - 1]).split(" -> ") #splitting up text in matching line of file to a temporary array to get the correct AI filename...
				matches = [element for element in tempArray if "{AIRENAMED}" in element] # Using list comprehension to find elements that contain "{AIRENAMED}"
				for match in matches:
					tempString = str(match)
					tempString = tempString.replace("{AIRENAMED}","") #Cleaning up filename to what it would appropriately be called when copied, theoretically... assuming no other operations were performed at this point.
					theoreticalFileToBeCopied = tempString
			i = i + 1

		i = 0
		
		while (i < len(matchingTextLinesArray)): #This while loop is intended to correct the file extension to .png if it finds that background-removal was engaged based on the file history text file data. Background removal always saves files as PNG.
			if "{BACKGROUNDREMOVED}" in lines[matchingTextLinesArray[i] - 1]: #Check all line numbers in array for any lines that have {BACKGROUNDREMOVED} in them...
				#Cleaning up filename to what it would appropriately be called when copied, theoretically... assuming no other operations were performed at this point.
				theoreticalFileToBeCopied = theoreticalFileToBeCopied.replace(".jpg",".png")
				theoreticalFileToBeCopied = theoreticalFileToBeCopied.replace(".JPG",".png")
				theoreticalFileToBeCopied = theoreticalFileToBeCopied.replace(".jpeg",".png")
				theoreticalFileToBeCopied = theoreticalFileToBeCopied.replace(".JPEG",".png")
				theoreticalFileToBeCopied = theoreticalFileToBeCopied.replace(".PNG",".png")
			i = i + 1
		
		i = 0
		
		while (i < len(matchingTextLinesArray)): #This while loop is intended to correct the file name to itself + the tag "_CROPPED" if it finds that Autocropper was engaged based on the file history text file data. Autocropper always resaves files with the _CROPPED tag at the end.
			if "{AUTOCROPPED}" in lines[matchingTextLinesArray[i] - 1]: #Check all line numbers in array for any lines that have {AUTOCROPPED} in them...
				#Cleaning up filename to what it would appropriately be called when copied, theoretically... assuming no other operations were performed at this point.
				parts = theoreticalFileToBeCopied.rsplit('.', 1) #splitting up text string from the right-most period and then adding _CROPPED into it.
				theoreticalFileToBeCopied = f"{parts[0]}_CROPPED.{parts[1]}"
				
			i = i + 1

		
		officialTitle = str(theoreticalFileToBeCopied) #cleaning up image file name to something presentable for folder generation...
		officialTitle = officialTitle.replace("_CROPPED", "")
		officialTitle = officialTitle.replace("_RECOLORED", "")
		officialTitle = officialTitle.replace("_", " ") 
		officialTitle = officialTitle.replace(".jpg", "")
		officialTitle = officialTitle.replace(".jpeg", "")
		officialTitle = officialTitle.replace(".JPG", "")
		officialTitle = officialTitle.replace(".JPEG", "")
		officialTitle = officialTitle.replace(".PNG", "")
		officialTitle = officialTitle.replace(".png", "")
		officialTitle = officialTitle.replace("\n", "")

		
		subfolder_path = os.path.join(output_data_folder, str(officialTitle)) #generating new subfolder in local output folder based on its cleaned up title...
		os.mkdir(subfolder_path)
		
		shutil.copy2(str(cacheFolder) + "/" + str(renamedOriginalFileName), str(subfolder_path)) #copying renamed original image equivalent from cache folder to proper subfolder in output folder...
		
		print("DIAGNOSTIC PAUSE." "CURRENT FILE NAME TO TENTATIVELY BE COPIED: " + str(theoreticalFileToBeCopied))
		time.sleep(1000)
		
		if str(basenameInputtedFile) != str(theoreticalFileToBeCopied): #This section of the program only copies the theoretical image file from the local input directory if and only if the theoretical file and original input file do not match. This is to protect from glitches if the user only elects metadata generation.
			###PATCH 11-13-23, Removes Possibly of New Line character glitch during file copy.###
			last_newline_index = theoreticalFileToBeCopied.rfind('\n')
			if last_newline_index != -1:  # Check if '\n' was found
				theoreticalFileToBeCopied = theoreticalFileToBeCopied[:last_newline_index] + theoreticalFileToBeCopied[last_newline_index + 1:] #remove the last occurrence of new line character...
			###ENED OF PATCH 11-13-23
			
			shutil.copy2(str(input_data_folder) + "/" + str(theoreticalFileToBeCopied), str(subfolder_path))
		
		i = 0
		
		while (i < len(matchingTextLinesArray)): #checking to see if metadata extraction was engaged and then copying over the appropriate metadata text file if applicable...
			if "{METADATAEXTRACTED}" in lines[matchingTextLinesArray[i] - 1]:
				#preparing for metadata file generation if applicable
				metaDataFileTempString = theoreticalFileToBeCopied
				metaDataFileTempString = metaDataFileTempString.replace("_CROPPED", "")
				metaDataFileTempString = metaDataFileTempString.replace(".jpg", "")
				metaDataFileTempString = metaDataFileTempString.replace(".jpeg", "")
				metaDataFileTempString = metaDataFileTempString.replace(".JPG", "")
				metaDataFileTempString = metaDataFileTempString.replace(".JPEG", "")
				metaDataFileTempString = metaDataFileTempString.replace(".PNG", "")
				metaDataFileTempString = metaDataFileTempString.replace(".png", "")
				metaDataFileTempString = metaDataFileTempString + "_metadata.txt"
				shutil.copy2(str(input_data_folder) + "/" + str(metaDataFileTempString), str(subfolder_path)) #actually copying metadata to local output folder here...
			i = i + 1
		
		file.close()
		
def find_text_in_file(file_path, search_text): #Text file searcher searches for a key word and then returns an array of all the line numbers where it was found.
	matchingTextLines_Array = [] #array to carry any possible matching text lines from base filename query...
	with open(file_path, 'r') as file:
		for line_number, line in enumerate(file, start=1):
			if search_text in line:
				matchingTextLines_Array.append(line_number)

	return matchingTextLines_Array
#function definitions


#imperative commands#
print('Consolidating edited images and their metadata file equivalents (if present) into folders in the consolidator output folder...')

_, _, files = next(os.walk(main_input_folder)) #counting files in main input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the main input directory...

filesList = [f for f in listdir(main_input_folder) if isfile(join(main_input_folder, f))] #parsing file manifest list for main input folder...

while i < file_count: #begin batch image crop batch cycle here
	sourceImageFileName = main_input_folder / filesList[i] #adjusting source image filename from main input folder for each iteration...
	
	consolidateFile(sourceImageFileName)
	
	i = i + 1
#imperative commands#


