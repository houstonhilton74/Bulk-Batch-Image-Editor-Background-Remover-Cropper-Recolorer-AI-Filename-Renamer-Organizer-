print("BE SURE TO READ THE README.TXT FILE IN MAIN PROGRAM DIRECTORY IF THIS IS YOUR FIRST TIME USING THIS PROGRAM FOR PROPER SETUP AND USAGE!")
import os
import subprocess
import numpy as np
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
from os.path import exists
import string
import linecache
import sys
import threading
from PyQt6.QtWidgets import QApplication, QDialog, QVBoxLayout, QComboBox, QLabel, QPushButton, QHBoxLayout, QLineEdit, QWidget
from PyQt6.QtGui import QPainter, QBrush, QPen, QColor, QFont, QPalette
from PyQt6 import QtCore
from PyQt6.QtCore import Qt
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QUrl

directorProgramFullPath = Path(__file__).parent.parent.parent / "Director.sh" #full path of director program...
configFile = Path(__file__).parent.parent.parent / "Config.txt" #config file location...

line_count = 0

with open(configFile, "r") as file: #reading how many lines are in config file... an "established" config file should have at least 50 lines in it...
    for line in file:
        line_count += 1

if line_count < 50: #if the configuration does not have at least 50 lines, it will be assummed that it is either corrupt or completely blank and will be automatically refreshed.
	print("It appears that this is the first time for you using this application. All processing parameters will be set to default configuration. It is highly recommended to check the README file for proper setup and usage.")
	with open(str(configFile), "w") as file: #clearing config.txt file to a "fresh" blank file with 50 lines for first-time users.
		for _ in range(50):
			file.write('\n')
	
with open(configFile, 'r') as file: #reading lines of configuration file... if there are any...
	lines = file.readlines()
	
###DIALOG BOX GENERATION SECTION###
class CenteredLabel(QLabel): #Generating new class "CenteredLabel" any label of this class will have text centered in it.
	def __init__(self, text):
		super().__init__(text)

	def paintEvent(self, event):
		painter = QPainter(self)
		painter.setPen(self.palette().color(self.foregroundRole()))
		painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.text())
		
class ControlPanel(QDialog): #This is where the actual dialog box is generated...
	def __init__(self):
		super().__init__()

		self.setWindowTitle("Automatic Bulk Image Formatter Control Panel")
		self.setGeometry(100, 100, 300, 200)

		layout = QVBoxLayout()
		
		#disclaimer. Good for instructing users that don't want to read first...
		self.readmeDisclaimer_label = CenteredLabel("Welcome to Bulk Image Formatter! Please note \n that it is highly recommended to read the \n README.txt file and run the program in diagnostics \n mode first if you are new at using this program.\n")
		layout.addWidget(self.readmeDisclaimer_label)
		
		# Drop-down toggle for Automatic Cropping
		self.crop_label = CenteredLabel("Bulk Automatic Cropping? Note: It is recommended \n to have Bulk Image Background Removal \n enabled as well for cropping  \n to work properly.")
		self.crop_toggle = QComboBox()
		
		self.crop_toggle.addItems(["Enabled", "Disabled"])
		if lines[5] == "cropImages=YES\n" or lines[5] == "\n": ###UPDATE Crop Images dropdown based on Config File Data...
			self.crop_toggle.setCurrentIndex(0) 
		else:
			#input("Test DETECTION for crop toggle! Toggle confirmed disabled!")
			self.crop_toggle.setCurrentIndex(1)
		layout.addWidget(self.crop_label)
		layout.addWidget(self.crop_toggle)
		# Drop-down toggle for Background Removal
		self.backgroundRemoval_label = CenteredLabel("Bulk Image Background Removal?")
		self.backgroundRemoval_toggle = QComboBox()
		self.backgroundRemoval_toggle.addItems(["Enabled", "Disabled"])

		if lines[4] == "backgroundRemoval=YES\n" or lines[4] == "\n":
			self.backgroundRemoval_toggle.setCurrentIndex(0) 
		else:
			self.backgroundRemoval_toggle.setCurrentIndex(1)
		layout.addWidget(self.backgroundRemoval_label)
		layout.addWidget(self.backgroundRemoval_toggle)

		# Drop-down toggle for In-between Processing
		self.in_between_label = CenteredLabel("Bulk in-between image(s) Processing?")
		self.in_between_toggle = QComboBox()
		self.in_between_toggle.addItems(["Enabled", "Disabled"])

		if lines[3] == "inBetweenImages=NO\n" or lines[3] == "\n":
			self.in_between_toggle.setCurrentIndex(1) 
		else:
			self.in_between_toggle.setCurrentIndex(0)
		layout.addWidget(self.in_between_label)
		layout.addWidget(self.in_between_toggle)
		
		# Drop-down toggle for AI Renamer Processing
		self.API_label = CenteredLabel("Bulk image AI file and resulting folder renaming? You can \n choose between using either Google Vision's API, \n Ebay's or not rename at all. Please see README \n for appropriate environment setup for these APIs.")
		self.API_toggle = QComboBox()
		self.API_toggle.addItems(["Do Not Rename", "Ebay", "Google"])
		
		###
		if lines[1] == "useAPIRenamer=NO\n" or lines[1] == "\n":
			self.API_toggle.setCurrentIndex(0)
		else:
			if lines[2] == "apiType=EBAY\n":
				self.API_toggle.setCurrentIndex(1)
			else:
				self.API_toggle.setCurrentIndex(2)
		###
		
		layout.addWidget(self.API_label)
		layout.addWidget(self.API_toggle)
		
		# Drop-down toggle for Metadata Text File Generation
		self.metadata_label = CenteredLabel("Bulk metadata text file generation? \n Please see README for appropriate \n environment setup if you're \n planning on using this API.")
		self.metadata_toggle = QComboBox()
		self.metadata_toggle.addItems(["Enabled", "Disabled"])
		
		if lines[6] == "generateMetadata=NO\n" or lines[6] == "\n":
			self.metadata_toggle.setCurrentIndex(1) 
		else:
			self.metadata_toggle.setCurrentIndex(0)
		layout.addWidget(self.metadata_label)
		layout.addWidget(self.metadata_toggle)
		
		# Text input box for Image Coloring Script
		self.pixelationScript_label = CenteredLabel("Would you like to bulk edit the pixel mapping of \n your images? Enter in your repixelation script below. \n If not, please leave this box blank. See README.txt \n file for repixelation script usage if you're using it for the first time.")
		self.pixelationScript_input = QLineEdit()
		
		if lines[0] == "pixelationOperationScript=NULL\n" or lines[0] == "\n":
			self.pixelationScript_input.setText("")
		else:
			tempText = str(lines[0])
			tempText = tempText.replace("pixelationOperationScript=", "")
			tempText = tempText.replace("\n", "")
			self.pixelationScript_input.setText(tempText)
			
		layout.addWidget(self.pixelationScript_label)
		layout.addWidget(self.pixelationScript_input)
		self.pixelationScript_input.setCursorPosition(0) #makes sure that the beginning of the input script always shows initially for monitors with limited space...
		
		# Button to start the process
		start_button = QPushButton("Start")
		start_button.clicked.connect(self.start_processing)

		# Add button to a horizontal layout to center it
		button_layout = QHBoxLayout()
		button_layout.addStretch(1)
		button_layout.addWidget(start_button)
		button_layout.addStretch(1)
		layout.addLayout(button_layout)
		
		self.donation_label = CenteredLabel("This project depends on donations for \n its continued maintenance and development.")
		self.donation_label2 = CenteredLabel("Thank you for all of your continued support! \n Feel free to donate at buymeacoffee.com/AutomaticFormatter")
		layout.addWidget(self.donation_label)
		layout.addWidget(self.donation_label2)
		
		self.setLayout(layout)
		self.show()

###DIALOG BOX GENERATION SECTION END###

	def start_processing(self):
		# This function will be called when the "Start Program" button is clicked
		api_option = self.API_toggle.currentText()
		metadata_option = self.metadata_toggle.currentText()
		crop_option = self.crop_toggle.currentText()
		backgroundRemoval_option = self.backgroundRemoval_toggle.currentText()
		in_between_option = self.in_between_toggle.currentText()
		image_script = self.pixelationScript_input.text()
		
		with open(str(configFile), "w") as file: #clearing config.txt file for refresh to what the current settings are in the GUI...
			for _ in range(50):
				file.write('\n')
		
		if image_script == "": #In this case, we're adjusting the image coloring script line in the config file...
			lines[0] = "pixelationOperationScript=NULL\n" #index offset by 1. This is really line #8.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		else:	
			lines[0] = "pixelationOperationScript=" + str(image_script) + "\n" #index offset by 1. This is really line #8
			with open(configFile, 'w') as file:
				file.writelines(lines)
		
		if api_option == "Do Not Rename": #beginning re-save procedure, line-by-line. In this case, we're adjusting the API rename config lines in the config file...
			lines[1] = "useAPIRenamer=NO\n" #index offset by 1. This is really line #2.
			lines[2] = "apiType=NULL\n" #index offset by 1. This is really line #3.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		
		if api_option == "Ebay": # In this case, we're adjusting the API rename config lines in the config file...
			lines[1] = "useAPIRenamer=YES\n" #index offset by 1. This is really line #2.
			lines[2] = "apiType=EBAY\n" #index offset by 1. This is really line #3
			with open(configFile, 'w') as file:
				file.writelines(lines)
			  
		if api_option == "Google": #In this case, we're adjusting the API rename config lines in the config file...
			lines[1] = "useAPIRenamer=YES\n" #index offset by 1. This is really line #2.
			lines[2] = "apiType=GOOGLE\n" #index offset by 1. This is really line #3.	
			with open(configFile, 'w') as file:
				file.writelines(lines)

		if in_between_option == "Enabled": #In this case, we're adjusting the in-between image processing line in the config file...
			lines[3] = "inBetweenImages=YES\n" #index offset by 1. This is really line #4.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		else:			
			lines[3] = "inBetweenImages=NO\n" #index offset by 1. This is really line #4.
			with open(configFile, 'w') as file:
				file.writelines(lines)
				
		if backgroundRemoval_option == "Enabled": #In this case, we're adjusting the background removal line in the config file...
			lines[4] = "backgroundRemoval=YES\n" #index offset by 1. This is really line #5.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		else:		
			lines[4] = "backgroundRemoval=NO\n" #index offset by 1. This is really line #5.	
			with open(configFile, 'w') as file:
				file.writelines(lines)
				
		if crop_option == "Enabled": #In this case, we're adjusting the crop config line in the config file...
			lines[5] = "cropImages=YES\n" #index offset by 1. This is really line #6.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		else:	
			lines[5] = "cropImages=NO\n" #index offset by 1. This is really line #6.	
			with open(configFile, 'w') as file:
				file.writelines(lines)
			
		if metadata_option == "Enabled": #In this case, we're adjusting the metadata config line in the config file...
			lines[6] = "generateMetadata=YES\n" #index offset by 1. This is really line #7.
			with open(configFile, 'w') as file:
				file.writelines(lines)
		else:
			lines[6] = "generateMetadata=NO\n" #index offset by 1. This is really line #7.	
			with open(configFile, 'w') as file:
				file.writelines(lines)
		
		dialog.accept() #close the dialogue window...
		
		os.system(str(directorProgramFullPath)) #Explicitly starting Director shell script here... The director loads in all stuff that was put into the configuration file.
		
if __name__ == '__main__':
	app = QApplication(sys.argv)
	dialog = ControlPanel()
	dialog.exec()
