#programmer reference#

#programmer reference#

#importing libraries and so forth#
import numpy as np
from PIL import Image, ImageOps, ImageDraw, ImageFont
from PIL import ImageEnhance
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
from image_enhancement import image_enhancement
from PIL.ExifTags import TAGS
import cv2 as cv
import cv2
import shutil
import imutils 
import linecache
import time
import re
from pathlib import Path


#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
recursiveSaveDir = Path(__file__).parent / "./Recursive_Image_Save_Temp_Dir/" #directory where an image being processed is temporarily saved to until a copy is finally saved into the appropriate local output directory.
configFileFullPath = Path(__file__).parent.parent.parent / "Config.txt" #full path of configuration file

######
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
######

fileCountInput = 0 #file counter for how many files are in input directory
i = 0 #generic iterator
currentOperationCode = "NULL" #current coloring operation code that is changed for each operation code found in the operation code script/array. This is customizable by the user's discretion and can be done in any order and allows operation codes to be used multiple times optionally.
operationCodeScriptString = "NULL" #Operation code script/array that is normally adjusted to what is saved in the configuration file. This is customizable by the user's discretion and can be done in any order and allows operation codes to be used multiple times as well as not require all codes to be used.

with open(str(configFileFullPath), "r") as file: #getting Operation Code Script string from Config.txt file...
	operationCodeScriptString = file.readline().strip()
	operationCodeScriptString = operationCodeScriptString.replace('pixelationOperationScript=', '') #cleanup stripped line from configuration file.
orientation = 999999 #Orientation EXIF data used for temporary storage purposes should EXIF data loss occur in some image conversions.
iNested = 0 #Nested iterator used to regulate nested while loop directing the operation codes. 
#variable initializations#


#function definitions
def repixelateImage(targetImage, repixelationCodeScript, historyLineNumber, orientation):
	
	#Image color balance auto correction and manual adjustment operation code main function. Inputs the current image of all images from input folder and outputs the color-changed image to local output folder. This program accepts the coloring adjustment/correction operation codes below. Each coloring effect is followed based on a 2D array that is fed into it with the expected operation codes, with the left-most being the first operation and the right-most being the last operation, in that order.
	#bbhe (Brightness Preserving Histogram Equalization) (No Parameters)
		#Kim, Yeong-Taeg.
		#Contrast enhancement using brightness preserving bi-histogram equalization.
		#IEEE transactions on Consumer Electronics 43, no. 1 (1997): 1-8.
	#bhepl (Bi-Histogram Equalization with a Plateau Limit) (No Parameters)
		#Ooi, Chen Hee, Nicholas Sia Pik Kong, and Haidi Ibrahim.
		#Bi-histogram equalization with a plateau limit for digital image enhancement.
		#IEEE transactions on consumer electronics 55, no. 4 (2009): 2072-2080.
	#bpheme (Brightness Preserving Histogram Equalization with Maximum Entropy) (No Parameters)
		#Wang, Chao, and Zhongfu Ye.
		#Brightness preserving histogram equalization with maximum entropy: a variational perspective.
		#IEEE Transactions on Consumer Electronics 51, no. 4 (2005): 1326-1334.
	#dsihe (Dualistic Sub-Image Histogram Equalization) (No Parameters)
		#Wang, Yu, Qian Chen, and Baeomin Zhang.
		#Image enhancement based on equal area dualistic sub-image histogram equalization method.
		#IEEE Transactions on Consumer Electronics 45, no. 1 (1999): 68-75.
	#fhsabp (Flattest Histogram Specification with Accurate Brightness Preservation) (No Parameters)
		#Wang, C., J. Peng, and Z. Ye.
		#Flattest histogram specification with accurate brightness preservation.
		#IET Image Processing 2, no. 5 (2008): 249-262.
	#ghe (Global Histogram Equalization) (No Parameters)
		#This function is similar to equalizeHist(image) in opencv.
	#mmbebhe (Minimum Mean Brightness Error Histogram Equalization) (No Parameters)
		#Chen, Soong-Der, and Abd Rahman Ramli.
		#Minimum mean brightness error bi-histogram equalization in contrast enhancement.
		#IEEE transactions on Consumer Electronics 49, no. 4 (2003): 1310-1319.
	#rlbhe (Range Limited Bi-Histogram Equalization) (No Parameters)
		#Zuo, Chao, Qian Chen, and Xiubao Sui.
		#Range limited bi-histogram equalization for image contrast enhancement.
		#Optik 124, no. 5 (2013): 425-431.
	#brightness{Decimal parameter}	
		#Adjusts image brightness.
		#This can be used to control the brightness of an image. An enhancement parameter of 0.0 gives a black image, a parameter of 1.0 gives the original image, and greater values increase the brightness of the image.
	#contrast{Decimal parameter}
		#Adjusts image contrast.
		#This can be used to control the contrast of an image, similar to the contrast control on a TV set. An enhancement parameter of 0.0 gives a solid gray image, a parameter of 1.0 gives the original image, and greater values increase the contrast of the image.
	#saturation{Decimal parameter}	
		#Adjusts image color balance.
		#This can be used to adjust the color balance of an image, in a manner similar to the controls on a color TV set. An enhancement parameter of 0.0 gives a black and white image. A parameter of 1.0 gives the original image. More indefinitely oversaturates the image.
	#sharpness{Decimal parameter}	
		#Adjusts image sharpness.
		#This can be used to adjust the sharpness of an image. An enhancement parameter of 0.0 gives a blurred image, a parameter of 1.0 gives the original image, and a parameter of 2.0 gives a sharpened image. More indefinitely sharpens the image.
	#colorize{[Red Color Integer Value 0-255(Inclusive)], [Green Color Integer Value 0-255(Inclusive)], [Blue Color Integer Value 0-255(Inclusive)]}
		#Colorizes an image with a given color, presented in an integer RGB format. Each RGB value is represented as an integer from 0-255 inclusive, passed as 3 arguments in the parameter.
	#mirror_horizontal
		#-Mirrors the image accross the x-axis. Requires no parameter.
	#mirror_vertical
		#-Mirrors the image accross the y-axis. Requires no parameter.
	#resize{[Float Horizontal Dimension Multiplier Value > 0 ],[Float Vertical Dimension Multiplier Value > 0]}
		#-Resizes image if the operation code is present. The resizing is done by multiplying decimal factors greater than 0 to the number of horazontal and vertical pixels via passing two parameters - one for each dimension.
	#rotate{[Float Image Rotation Degree Value -360.0-360.0(Inclusive)]}
		#-Manually rotates image if the operation code is present. Any float number between -360.0 to 360.0 inclusive after the rotation keyword is treated as the rotation angle parameter. The positive or negative denotes the direction of the rotation.
	#textstamp{[Text String], [0 < Relative Location Multiplier Horizontal Dimension Float < 1], [0 < Relative Location Multiplier Vertical Dimension Float < 1], [Font Size Integer > 0], [Red Color Level RGB Integer 0-255(Inclusive)], Green Color Level RGB Integer 0-255(Inclusive)], Blue Color Level RGB Integer 0-255(Inclusive)]}
		#-Adds a text stamp to an image. The user may customize what text is stamped, its location relative to the resolution for each image, font size, and font color, in that argument order. Please note that, at this time, 
		#-Due to lack of font .ttf file location and indexing standardization on Linux distributions, please make sure that you have installed "DejaVuSans.ttf" globally on your system for effective indexing at this time when using the text stamper. Most distributions should have it by default, but just in case, double-check that if there are any issues

		
	#Example Usage Operation Code Script:
		#textstamp("Honey, I shrunk the kids.", 0.25, 0.25, 96, 0, 0, 255), rotate(40.1), mirror_vertical, colorize(0, 255, 0)	
	
	
	image = Image.open(str(targetImage))###HOTFIX### ImageEnhance library does not keep EXIF data at time of writing, so the orientation metadata may be dropped in translation accidentally if the library is called, so we're going to preserve it early.
	if "exif" in image.info: # Check if the image has Exif metadata
		exif_data = image._getexif()
		if exif_data is not None: #bug fix - code patch that accounts for images that do not have or have non-standard or bad EXIF data. It changes orientation to a "junk" number. If that happens, no orientation adjustments are made.
			orientation = exif_data.get(274) # Extract the orientation tag (tag number 274)
		else:
			orientation = 999999
		#input("Current Image Orientation: " + str(orientation)) ###CODE used for diagnostics in case there are any EXIF orientation bugs that pop up from time to time...
		
	for filename in os.listdir(recursiveSaveDir): #attempting removal of all files in recursive directory...
		file_path = os.path.join(recursiveSaveDir, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutil.rmtree(file_path)
		except Exception as e:
			print('Failed to delete %s. Reason: %s' % (file_path, e))
	
	RecursiveImageFilePathandName = str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)) #generating temporary file name to be used during recursive recoloring processing for each image file.
	shutil.copyfile(targetImage, RecursiveImageFilePathandName) #making a first time copy of file being processed into recursive directory to allow multiple color correction operations...
	print('Recursive image first time copied!')
	
	iNested = 0 #Resetting iteration for operation code array for peace of mind...
	
	operationCodeScriptArray = re.split(r', (?![^()]*\))', repixelationCodeScript) #split original operation code string separated by commas and a single space into an Array usable by Python. The exceptions that avoid splits are any commas and spaces found in parenthesis.
	
	while iNested < len(operationCodeScriptArray):
		
		currentOperationCode = str(operationCodeScriptArray[iNested]) ###This segment of code looks for the first set of quoted text, which can be used for a title in the textstamp operation code later. It is done early to prevent lowercase filters.
		pattern = r'"(.*?)"'
		match = re.search(pattern, currentOperationCode) # Search for the first occurrence of quoted string in the text
		if match:# If a match is found, return the stamp text title within the quotes
			textStampString = str(match.group(1))
		else:
			textStampString = ""
		
		
		currentOperationCode = str(operationCodeScriptArray[iNested]).lower() #Set current operation to the appropriate "part" of operations list. It will automatically reach each as lowercase, as users may or may not use capitalization when entering in commands for the script.
		
		operationCodeValidated = False #boolean trigger. This does not get enabled as true if no valid operation code was detected. If this happens, the program will simply skip to the next step if there is one, or end the script altogether depending on where the error occured.
		
		if currentOperationCode == "bbhe": #logic operations occur here for determine whether or not different image correction algorithms will occur. Please note that these occur sequentially in alphabetical order.
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "bhepl":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BHEPL()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode== "bpheme":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BPHEME()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "dsihe":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.DSIHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "fhsabp":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.FHSABP()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "ghe":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.GHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "mmbebhe":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.MMBEBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "rlbhe":
			operationCodeValidated = True
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.RLBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if "brightness" in currentOperationCode: #Handler for manual brightness adjustment if the operation code is present. Any number after the brightness keyword is treated as the brightness parameter.
			operationCodeValidated = True
			
			try:
				parameter = float(str(get_text_between_parentheses(currentOperationCode))) #Deriving the parameter from the string found in the paraenthesis of the current operation code in use...
			except ValueError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except TypeError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except OverflowError:
				print("WARNING! Parameter value overflow in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			else:
				img = Image.open(RecursiveImageFilePathandName)
				enhancer = ImageEnhance.Brightness(img)
				enhancer.enhance(parameter).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on brightness parameter...
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "saturation" in currentOperationCode: #Handler for manual saturation adjustment if the operation code is present. Any number after the saturation keyword is treated as the saturation parameter.
			operationCodeValidated = True
			
			try:
				parameter = float(str(get_text_between_parentheses(currentOperationCode))) #Deriving the parameter from the string found in the paraenthesis of the current operation code in use...
			except ValueError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except TypeError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except OverflowError:
				print("WARNING! Parameter value overflow in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			else:
				img = Image.open(RecursiveImageFilePathandName)
				enhancer = ImageEnhance.Color(img)
				enhancer.enhance(parameter).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on saturation parameter...
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "contrast" in currentOperationCode: #Handler for manual contrast adjustment if the operation code is present. Any number after the contrast keyword is treated as the contrast parameter.
			operationCodeValidated = True
			
			try:
				parameter = float(str(get_text_between_parentheses(currentOperationCode))) #Deriving the parameter from the string found in the paraenthesis of the current operation code in use...
			except ValueError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except TypeError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except OverflowError:
				print("WARNING! Parameter value overflow in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			else:
				img = Image.open(RecursiveImageFilePathandName)
				enhancer = ImageEnhance.Contrast(img)
				enhancer.enhance(parameter).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on contrast parameter...
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "sharpness" in currentOperationCode: #Handler for manual sharpness adjustment if the operation code is present. Any number after the sharpness keyword is treated as the sharpness parameter.
			operationCodeValidated = True
			
			try:
				parameter = float(str(get_text_between_parentheses(currentOperationCode))) #Deriving the parameter from the string found in the paraenthesis of the current operation code in use...
			except ValueError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except TypeError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except OverflowError:
				print("WARNING! Parameter value overflow in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			else:
				img = Image.open(RecursiveImageFilePathandName)
				enhancer = ImageEnhance.Sharpness(img)
				enhancer.enhance(parameter).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on sharpness parameter...
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)

####NEW COMMANDS added here as of 2-23-24. BE SURE TO UPDATE THE DOCUMENTATION FOR THEM AND THEN REMOVE THIS COMMENT WHEN FINISHED.####

		if currentOperationCode == "mirror_vertical": #Handler for mirroring the image accross the y-axis.
			operationCodeValidated = True
				
			img = Image.open(RecursiveImageFilePathandName)
			mirrored_img = img.transpose(Image.FLIP_LEFT_RIGHT)
			mirrored_img.save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #resaving over old file in recursive save directory
			
			image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
			
		if currentOperationCode == "mirror_horizontal": #Handler for mirroring the image accross the x-axis.
			operationCodeValidated = True
				
			img = Image.open(RecursiveImageFilePathandName)
			mirrored_img = img.transpose(Image.FLIP_TOP_BOTTOM)
			mirrored_img.save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #resaving over old file in recursive save directory
			
			image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
			
		if "rotate" in currentOperationCode: #Handler for manual rotation of image if the operation code is present. Any float number between -360.0 to 360.0 after the rotation keyword is treated as the rotation angle parameter. The positive or negative denotes the direction of the rotation.
			operationCodeValidated = True
			
			try:
				parameter = float(str(get_text_between_parentheses(currentOperationCode))) #Deriving the parameter from the string found in the paraenthesis of the current operation code in use... This will be the float value for the angle of rotation...
			except ValueError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except TypeError:
				print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			except OverflowError:
				print("WARNING! Parameter value overflow in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
			else:
				if parameter > 360 or parameter < -360:
					print("Parameter error detected for a rotation operation! Rotation angle should not exceed 360 degrees or go below -360 degrees! That operation will be skipped.")
				else:
					image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
					image = imutils.rotate_bound(image, parameter)
					cv2.imwrite(str(RecursiveImageFilePathandName), image)
				
					image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
					if orientation == 6:
						image = imutils.rotate_bound(image, 90)
					if orientation == 8:
						image = imutils.rotate_bound(image, -90)
					cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
			
		if "resize" in currentOperationCode: #Handler for resizing image if the operation code is present. The resizing is done by multiplying factors to the number of horazontal and vertical pixels via passing two parameters for each axis. 
			operationCodeValidated = True
			
			parameterValid = True #Boolean logic variable that trips if ANY parameter passed in is deemed invalid. It will be checked later as a condition to see if the resizing operation can occur.
			parameters = get_text_between_parentheses(currentOperationCode)
			
			parametersArray = parameters.split(", ") #generating array for x-axis and y-axis pixel resolution multiplier parameters.
			parametersArrayLength = len(parametersArray)
				
			if parametersArrayLength < 2: #there should be at least two parameters passed by the user, as all images are two-dimensional.
				parameterValid = False
				print("Error! Not enough parameters detected for a resize operation at " + str(currentOperationCode) + " It will be skipped. Check your syntax.")
			else:
				try:
					parameter = float(parametersArray[0]) #Checking x-axis multiplier parameter for validity...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter <= 0:
						parameterValid = False
						print("WARNING! Parameter at or below 0 in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
					
				try:
					parameter = float(parametersArray[1]) #Checking y-axis multiplier parameter for validity...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:	
					if parameter <= 0:
						parameterValid = False
						print("WARNING! Parameter at or below 0 in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
						
			if parameterValid == True: #actual resizing occurs here IF and ONLY IF the first two parameters supplied by the user for this operation code are considered valid.
				img = Image.open(RecursiveImageFilePathandName)
				original_width, original_height = img.size # Get the original dimensions
				new_width = int(original_width * float(parametersArray[0])) # Calculate the new dimensions
				new_height = int(original_height * float(parametersArray[1]))
				resized_img = img.resize((new_width, new_height))
				resized_img.save(RecursiveImageFilePathandName)
				
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)
				
				
		if "colorize" in currentOperationCode: #Handler for colorizing an image with a given color, presented in an integer RGB format. Each RGB value is represented as an integer from 0-255, passed as 3 arguments in the parameter. 
			operationCodeValidated = True
			
			parameterValid = True #Boolean logic variable that trips if ANY parameter passed in is deemed invalid. It will be checked later as a condition to see if the resizing operation can occur.
			parameters = get_text_between_parentheses(currentOperationCode)
			
			parametersArray = parameters.split(", ") #generating array for x-axis and y-axis pixel resolution multiplier parameters.
			parametersArrayLength = len(parametersArray)
				
			if parametersArrayLength < 3: #there should be at least three parameters passed by the user, as the required color uses the RGB color value system.
				parameterValid = False
				print("Error! Not enough parameters detected for a resize operation at " + str(currentOperationCode) + " It will be skipped. Check your syntax.")
			else:
				try:
					parameter = int(parametersArray[0]) #Checking red score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in red score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				
				try:
					parameter = int(parametersArray[1]) #Checking green score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in green score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")	
						
				try:
					parameter = int(parametersArray[2]) #Checking blue score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in blue score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")		
						
			if parameterValid == True: #actual colorizing occurs here IF and ONLY IF the first three parameters supplied by the user for this operation code are considered valid.
				img = Image.open(RecursiveImageFilePathandName)
				color = (int(parametersArray[0]), int(parametersArray[1]), int(parametersArray[2])) #defining the RGB color tuple based on the validated arguments passed by the user.
				color_image = Image.new("RGB", img.size, color) # Create a solid color image with the specified RGB color. This will be blended into the target image.
				result_image = Image.blend(img, color_image, alpha=0.5)# Blend the original image with the color image using the specified alpha value
				result_image.save(RecursiveImageFilePathandName) # Save the colorized image
				
				image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
				if orientation == 6:
					image = imutils.rotate_bound(image, 90)
				if orientation == 8:
					image = imutils.rotate_bound(image, -90)
				cv2.imwrite(str(RecursiveImageFilePathandName), image)
				
				
		if "textstamp" in currentOperationCode: #Handler for adding a text stamp to an image. The user may customize what text is stamped, its location relative to the resolution for each image, font size, and font color, in that argument order.
			#The 7 arguments are as follows, in integer, float, or string format depending on the data type: [Text String], [Relative Location Multiplier X-axis Float], [Relative Location Multiplier Y-axis Float], [Font Size Integer], [Red Color Level RGB Integer], Green Color Level RGB Integer], Blue Color Level RGB Integer]  
			
			operationCodeValidated = True
			parameterValid = True #Boolean logic variable that trips if ANY parameter passed in is deemed invalid. It will be checked later as a condition to see if the textstamping operation can occur.
			parameters = get_text_between_parentheses(currentOperationCode) #getting main parameters as text file.
			
			pattern = r',\s*(?=(?:[^"]*"[^"]*")*[^"]*$)' #splitting parameters to a usable array, while keeping any comma-space delimiters in tact for the first arguement that uses quotes.
			parametersArray = re.split(pattern, parameters) # Split the text using the regular expression pattern
			parametersArray = [segment.strip() for segment in parametersArray] # Remove leading and trailing spaces from segments
			
			parametersArrayLength = len(parametersArray)
				
			if parametersArrayLength < 7: #there should be at least 7 parameters passed by the user for proper text stamping.
				parameterValid = False
				print("Error! Not enough parameters detected for a resize operation at " + str(currentOperationCode) + " It will be skipped. Check your syntax.")
			else:
				if len(textStampString) <= 0: #checking to see if a string of text was found earlier, at the beginning of the operation code loop - before everything was filtered down to lowercase.
					parameterValid = False
					print("No text was found to stamp on to the image at operation code " + str(currentOperationCode) + ". Check your syntax!")
					
				try: #Check x-axis relative placement multiplyer to make sure that it is a valid parameter. It should be above 0 AND below 1.
					parameter = float(parametersArray[1]) 
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 1:
						parameterValid = False
						print("WARNING! Relative stamp x-axis placement value below 0 or above 1 in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				
				try: #Check y-axis relative placement multiplyer to make sure that it is a valid parameter. It should be above 0 AND below 1.
					parameter = float(parametersArray[2]) 
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 1:
						parameterValid = False
						print("WARNING! Relative stamp y-axis placement value below 0 or above 1 in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
						
				try: #Check font size integer to make sure that it is a valid parameter. It should be at least 1.
					parameter = int(parametersArray[3]) 
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 1:
						parameterValid = False
						print("WARNING! Font size either lower than 1 at operation code " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
						
				try:
					parameter = int(parametersArray[4]) #Checking red score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in red score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				
				try:
					parameter = int(parametersArray[5]) #Checking green score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in green score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")	
						
				try:
					parameter = int(parametersArray[6]) #Checking blue score integer value for validity. It should be between 0 and 255 inclusive...
				except ValueError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except TypeError:
					parameterValid = False
					print("WARNING! Invalid parameter in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				except OverflowError:
					parameterValid = False
					print("WARNING! Parameter value too high in " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
				else:
					if parameter < 0 or parameter > 255:
						parameterValid = False
						print("WARNING! Parameter below 0 or above 255 in blue score slot " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
						
				if parameterValid == True: #actual text stamping occurs here IF and ONLY IF the first seven parameters supplied by the user for this operation code are considered valid.
					print(' ')
					print('Note: Due to lack of font .ttf file location standardization on Linux distributions, please make sure that you have installed "DejaVuSans.ttf" globally on your system for effective indexing at this time when using the bulk text stamper. Most distributions should have it by default, but just in case, double-check that if there are any issues.')
					print(' ')
					img = Image.open(RecursiveImageFilePathandName) # Open the image file
					draw = ImageDraw.Draw(img) # Initialize drawing context
					font_color = int(parametersArray[4]), int(parametersArray[5]), int(parametersArray[6])#define font color as tuple, referencing corresponding slots from user-inputted arguments
					font_size = int(parametersArray[3])
					original_width, original_height = img.size # Getting the original image dimensions for relative text position calculations...
					relative_x = int(original_width * float(parametersArray[1])) # Calculate the new dimensions
					relative_y = int(original_height * float(parametersArray[2]))
					position = relative_x, relative_y #create tuple for final calculated relative position.										  
					
					#font = ImageFont.load_default()
					font = ImageFont.truetype("DejaVuSans.ttf", font_size)
					
					draw.text(position, textStampString, font=font, fill=font_color) # Draw the text on the image
					img.save(RecursiveImageFilePathandName) # Save the image with the text
				
												  
					image = cv2.imread(str(RecursiveImageFilePathandName)) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
					if orientation == 6:
						image = imutils.rotate_bound(image, 90)
					if orientation == 8:
						image = imutils.rotate_bound(image, -90)
					cv2.imwrite(str(RecursiveImageFilePathandName), image)
					
			
#########

		if operationCodeValidated == False: #a simple warning to the user if no valid operation code was detected for the current inputted operation code in the repixelation script.
			print("WARNING! Invalid operation code " + str(currentOperationCode) + " detected in repixelation script. This operation code will be skipped. Check your syntax!")
		
		iNested = iNested + 1
		
		###NESTED LOOP ENDS. FILE FINALIZATION OCCURS AFTER THIS. WATCH YOUR TABBING!###
		
	p = Path(RecursiveImageFilePathandName) #renaming finalized recursive file to have "_REPIXELATED" at the end of the file name. It helps with file history tracing stability... Also, updating the renamed file name reference to a new variable...
	new_file_name = f"{p.stem}_REPIXELATED{p.suffix}"
	p.rename(Path(p.parent, new_file_name))
		
	updated_file_reference = p.parent / new_file_name
		
	#print('Finalized file path name: ' + str(updated_file_reference))
		
	RecursiveImageFilePathandName = updated_file_reference
		
	shutil.copyfile(RecursiveImageFilePathandName, str(output_data_folder) + '/' + str(os.path.basename(RecursiveImageFilePathandName))) #copying image file used in recursive calls into local output folder. This is the finalized target image file for each inputted image file.
		
	######
	baseOutputFile = str(os.path.basename(RecursiveImageFilePathandName)) #generating the outputted file name so that it can be recorded into the file history text file...
	fileHistoryOutputFile(baseOutputFile, historyLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
	######
		
	#input("Outputted file from recolor: " + str(baseOutputFile))
	
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {REPIXELATED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
		
def get_text_between_parentheses(text): #mini function that gets any parameters inside the parenthesis of any relevant operation code instance in the repixelation script. If no proper paranthesis boundaries were found, it will return 'None.'
	start_index = text.find("(")
	end_index = text.find(")")
	if start_index != -1 and end_index != -1:
		return text[start_index + 1 : end_index]
	else:
		return None


#function definitions

#imperative commands#
print('Running bulk image pixel mapping adjustments...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #begin batch image crop batch cycle here
	sourceImageFileName = input_data_folder / filesList[i] #adjusting source image filename for each iteration
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	repixelateImage(sourceImageFileName, operationCodeScriptString, fileHistoryTextLineNumber, orientation)
	
	print('Repixelated image ' + str(i + 1) + ' of ' + str(file_count) + '. ' + baseName + ' completed.')
	i = i + 1
	
#print("Diagnostic pause")
#time.sleep(10000)
#imperative commands#


