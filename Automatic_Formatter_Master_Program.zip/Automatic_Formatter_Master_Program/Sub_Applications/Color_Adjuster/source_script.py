#programmer reference#

#programmer reference#

#importing libraries and so forth#
import numpy as np
from PIL import Image, ImageOps
from PIL import ImageEnhance
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
from image_enhancement import image_enhancement
from PIL.ExifTags import TAGS
import cv2 as cv
import cv2
import shutil
import imutils 
import linecache
import time
from pathlib import Path


#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
recursiveSaveDir = Path(__file__).parent / "./Recursive_Image_Save_Temp_Dir/" #directory where an image being processed is temporarily saved to until a copy is finally saved into the appropriate local output directory.
configFileFullPath = Path(__file__).parent.parent.parent / "Config.txt" #full path of configuration file

######
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
######

fileCountInput = 0 #file counter for how many files are in input directory
i = 0 #generic iterator
currentOperationCode = "NULL" #current coloring operation code that is changed for each operation code found in the operation code script/array. This is customizable by the user's discretion and can be done in any order and allows operation codes to be used multiple times optionally.
operationCodeScriptString = "NULL" #Operation code script/array that is normally adjusted to what is saved in the configuration file. This is customizable by the user's discretion and can be done in any order and allows operation codes to be used multiple times as well as not require all codes to be used.

with open(str(configFileFullPath), "r") as file: #getting Operation Code Script string from Config.txt file...
	operationCodeScriptString = file.readline().strip()
	operationCodeScriptString = operationCodeScriptString.replace('coloringOperationScript=', '') #cleanup stripped line from configuration file.
orientation = 999999 #Orientation EXIF data used for temporary storage purposes should EXIF data loss occur in some image conversions.
iNested = 0 #Nested iterator used to regulate nested while loop directing the operation codes. 
#variable initializations#


#function definitions
def recolorImage(targetImage, colorCodeScript, historyLineNumber, orientation):
	
	#Image color balance auto correction and manual adjustment operation code main function. Inputs the current image of all images from input folder and outputs the color-changed image to local output folder. This program accepts the coloring adjustment/correction operation codes below. Each coloring effect is followed based on a 2D array that is fed into it with the expected operation codes, with the left-most being the first operation and the right-most being the last operation, in that order.
	#BBHE (Brightness Preserving Histogram Equalization) (No Parameters)
		#Kim, Yeong-Taeg.
		#Contrast enhancement using brightness preserving bi-histogram equalization.
		#IEEE transactions on Consumer Electronics 43, no. 1 (1997): 1-8.
	#BHEPL (Bi-Histogram Equalization with a Plateau Limit) (No Parameters)
		#Ooi, Chen Hee, Nicholas Sia Pik Kong, and Haidi Ibrahim.
		#Bi-histogram equalization with a plateau limit for digital image enhancement.
		#IEEE transactions on consumer electronics 55, no. 4 (2009): 2072-2080.
	#BPHEME (Brightness Preserving Histogram Equalization with Maximum Entropy) (No Parameters)
		#Wang, Chao, and Zhongfu Ye.
		#Brightness preserving histogram equalization with maximum entropy: a variational perspective.
		#IEEE Transactions on Consumer Electronics 51, no. 4 (2005): 1326-1334.
	#DSIHE (Dualistic Sub-Image Histogram Equalization) (No Parameters)
		#Wang, Yu, Qian Chen, and Baeomin Zhang.
		#Image enhancement based on equal area dualistic sub-image histogram equalization method.
		#IEEE Transactions on Consumer Electronics 45, no. 1 (1999): 68-75.
	#FHSABP (Flattest Histogram Specification with Accurate Brightness Preservation) (No Parameters)
		#Wang, C., J. Peng, and Z. Ye.
		#Flattest histogram specification with accurate brightness preservation.
		#IET Image Processing 2, no. 5 (2008): 249-262.
	#GHE (Global Histogram Equalization) (No Parameters)
		#This function is similar to equalizeHist(image) in opencv.
	#MMBEBHE (Minimum Mean Brightness Error Histogram Equalization) (No Parameters)
		#Chen, Soong-Der, and Abd Rahman Ramli.
		#Minimum mean brightness error bi-histogram equalization in contrast enhancement.
		#IEEE transactions on Consumer Electronics 49, no. 4 (2003): 1310-1319.
	#RLBHE (Range Limited Bi-Histogram Equalization) (No Parameters)
		#Zuo, Chao, Qian Chen, and Xiubao Sui.
		#Range limited bi-histogram equalization for image contrast enhancement.
		#Optik 124, no. 5 (2013): 425-431.
	#BRIGHTNESS{Decimal Factor}	
		#Adjusts image brightness.
		#This can be used to control the brightness of an image. An enhancement factor of 0.0 gives a black image, a factor of 1.0 gives the original image, and greater values increase the brightness of the image.
	#CONTRAST{Decimal Factor}
		#Adjusts image contrast.
		#This can be used to control the contrast of an image, similar to the contrast control on a TV set. An enhancement factor of 0.0 gives a solid gray image, a factor of 1.0 gives the original image, and greater values increase the contrast of the image.
	#SATURATION{Decimal Factor}	
		#Adjusts image color balance.
		#This can be used to adjust the color balance of an image, in a manner similar to the controls on a color TV set. An enhancement factor of 0.0 gives a black and white image. A factor of 1.0 gives the original image. More indefinitely oversaturates the image.
	#SHARPNESS{Decimal Factor}	
		#Adjusts image sharpness.
		#This can be used to adjust the sharpness of an image. An enhancement factor of 0.0 gives a blurred image, a factor of 1.0 gives the original image, and a factor of 2.0 gives a sharpened image. More indefinitely sharpens the image.
	
	image = Image.open(str(targetImage))###HOTFIX### ImageEnhance library does not keep EXIF data at time of writing, so the orientation metadata may be dropped in translation accidentally if the library is called, so we're going to preserve it early.
	if "exif" in image.info: # Check if the image has Exif metadata
		exif_data = image._getexif()
		if exif_data is not None: #bug fix - code patch that accounts for images that do not have or have non-standard or bad EXIF data. It changes orientation to a "junk" number. If that happens, no orientation adjustments are made.
			orientation = exif_data.get(274) # Extract the orientation tag (tag number 274)
		else:
			orientation = 999999
		#input("Current Image Orientation: " + str(orientation)) ###CODE used for diagnostics in case there are any EXIF orientation bugs that pop up from time to time...
		
	for filename in os.listdir(recursiveSaveDir): #attempting removal of all files in recursive directory...
		file_path = os.path.join(recursiveSaveDir, filename)
		try:
			if os.path.isfile(file_path) or os.path.islink(file_path):
				os.unlink(file_path)
			elif os.path.isdir(file_path):
				shutil.rmtree(file_path)
		except Exception as e:
			print('Failed to delete %s. Reason: %s' % (file_path, e))
	
	RecursiveImageFilePathandName = str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)) #generating temporary file name to be used during recursive recoloring processing for each image file.
	shutil.copyfile(targetImage, RecursiveImageFilePathandName) #making a first time copy of file being processed into recursive directory to allow multiple color correction operations...
	print('Recursive image first time copied!')
	
	iNested = 0 #Resetting iteration for operation code array for peace of mind...
	operationCodeScriptArray = colorCodeScript.split(",") #split original operation code string separated by commas into an Array usable by Python.
	
	while iNested < len(operationCodeScriptArray):
		currentOperationCode = operationCodeScriptArray[iNested] #Set current operation to the appropriate "part" of operations list.
		
		if currentOperationCode == "BBHE": #logic operations occur here for determine whether or not different image correction algorithms will occur. Please note that these occur sequentially in alphabetical order.
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "BHEPL":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BHEPL()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode== "BPHEME":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.BPHEME()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "DSIHE":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.DSIHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "FHSABP":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.FHSABP()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "GHE":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.GHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "MMBEBHE":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.MMBEBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if currentOperationCode == "RLBHE":
			inputImage = cv.imread(str(RecursiveImageFilePathandName)) #defining image to be converted temporarily into CV array...
			ie = image_enhancement.IE(inputImage, 'HSV')
			ie = ie.RLBHE()
			output = ie
			cv.imwrite(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage)), output) #temporarily outputting color adjusted file back into recursive folder. Note: The previous recursive image file will be overwritten each time.
		
		if "BRIGHTNESS" in currentOperationCode: #Handler for manual brightness adjustment if the operation code is present. Any number after the brightness keyword is treated as the brightness factor.
			currentOperationCode = currentOperationCode.replace('BRIGHTNESS', '') #removing official operation code in preparation for deriving operating factor...
			factor = float(currentOperationCode) #Deriving the factor from the string found in operation code array...
			img = Image.open(RecursiveImageFilePathandName)
			enhancer = ImageEnhance.Brightness(img)
			enhancer.enhance(factor).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on brightness parameter/factor...
			image = cv2.imread(RecursiveImageFilePathandName) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "SATURATION" in currentOperationCode: #Handler for manual saturation adjustment if the operation code is present. Any number after the saturation keyword is treated as the saturation factor.
			currentOperationCode = currentOperationCode.replace('SATURATION', '') #removing official operation code in preparation for deriving operating factor...
			factor = float(currentOperationCode) #Deriving the factor from the string found in operation code array...
			img = Image.open(RecursiveImageFilePathandName)
			enhancer = ImageEnhance.Color(img)
			enhancer.enhance(factor).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on brightness parameter/factor...
			image = cv2.imread(RecursiveImageFilePathandName) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "CONTRAST" in currentOperationCode: #Handler for manual contrast adjustment if the operation code is present. Any number after the contrast keyword is treated as the contrast factor.
			currentOperationCode = currentOperationCode.replace('CONTRAST', '') #removing official operation code in preparation for deriving operating factor...
			factor = float(currentOperationCode) #Deriving the factor from the string found in operation code array...
			img = Image.open(RecursiveImageFilePathandName)
			enhancer = ImageEnhance.Contrast(img)
			enhancer.enhance(factor).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on brightness parameter/factor...
			image = cv2.imread(RecursiveImageFilePathandName) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
		if "SHARPNESS" in currentOperationCode: #Handler for manual sharpness adjustment if the operation code is present. Any number after the sharpness keyword is treated as the sharpness factor.
			currentOperationCode = currentOperationCode.replace('SHARPNESS', '') #removing official operation code in preparation for deriving operating factor...
			factor = float(currentOperationCode) #Deriving the factor from the string found in operation code array...
			img = Image.open(RecursiveImageFilePathandName)
			enhancer = ImageEnhance.Sharpness(img)
			enhancer.enhance(factor).save(str(recursiveSaveDir) + '/' + str(os.path.basename(targetImage))) #save enhanced image based on brightness parameter/factor...
			image = cv2.imread(RecursiveImageFilePathandName) ###HOTFIX: Auto adjusting rotation to account for odd EXIF orientation data that may have been lost during the copying process.
			if orientation == 6:
				image = imutils.rotate_bound(image, 90)
			if orientation == 8:
				image = imutils.rotate_bound(image, -90)
			cv2.imwrite(str(RecursiveImageFilePathandName), image)
			
	
		p = Path(RecursiveImageFilePathandName) #renaming finalized recursive file to have "_RECOLORED" at the end of the file name. It helps with file history tracing stability... Also, updating the renamed file name reference to a new variable...
		new_file_name = f"{p.stem}_RECOLORED{p.suffix}"
		p.rename(Path(p.parent, new_file_name))
		
		updated_file_reference = p.parent / new_file_name
		
		#print('Finalized file path name: ' + str(updated_file_reference))
		
		RecursiveImageFilePathandName = updated_file_reference
		
		shutil.copyfile(RecursiveImageFilePathandName, str(output_data_folder) + '/' + str(os.path.basename(RecursiveImageFilePathandName))) #copying image file used in recursive calls into local output folder. This is the finalized target image file for each inputted image file.
		
		
		######
		baseOutputFile = str(os.path.basename(RecursiveImageFilePathandName)) #generating the outputted file name so that it can be recorded into the file history text file...
		fileHistoryOutputFile(baseOutputFile, historyLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
		######
		
		#input("Outputted file from recolor: " + str(baseOutputFile))
		
		iNested = iNested + 1

######
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {COLORADJUSTED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
######

#function definitions

#imperative commands#
print('Running bulk image coloring adjustments...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #begin batch image crop batch cycle here
	sourceImageFileName = input_data_folder / filesList[i] #adjusting source image filename for each iteration
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	recolorImage(sourceImageFileName, operationCodeScriptString, fileHistoryTextLineNumber, orientation)
	
	print('Color-adjusted image ' + str(i + 1) + ' of ' + str(file_count) + '. ' + baseName + ' completed.')
	i = i + 1
	
#input("Diagnostic pause. Press Enter to continue.")
#imperative commands#


