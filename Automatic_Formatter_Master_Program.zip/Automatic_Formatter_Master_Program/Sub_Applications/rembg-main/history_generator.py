#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
import linecache
#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
fileCountInput = 0 #file counter for how many files are in input directory
i = 0 #generic iterator
#variable initializations#


#function definitions
		
######
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {BACKGROUNDREMOVED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
######

#function definitions

#imperative commands#
print('Generating history data of image background removal program...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #begin batch image crop batch cycle here
	######
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	bgRemovalEquivalentBaseName = baseName.replace(".jpg", ".png").replace(".JPG", ".png").replace(".jpeg", ".png").replace(".JPEG", ".png")
	######
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	######
	baseOutputFile = str(bgRemovalEquivalentBaseName) #generating the outputted file name so that it can be recorded into the file history text file...
	fileHistoryOutputFile(baseOutputFile, fileHistoryTextLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
	######
	
	i = i + 1
	
print("Background removal history data processing completed.")
#input("Press Enter to continue.")
#imperative commands#


