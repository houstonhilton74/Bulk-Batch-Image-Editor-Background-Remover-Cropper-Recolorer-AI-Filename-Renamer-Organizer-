#programmer reference#

#programmer reference#

#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
from os.path import exists
from google.cloud import vision
import random
import string
import linecache
#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
configFile = Path(__file__).parent.parent.parent / "Config.txt"
######
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
######
####PATCH FOR METADATA FIX. THIS IS THE METADATA FOLDER. IT IS ESTABLISHED WHEN THE MAIN SCRIPT STARTS. NOT WHEN THIS SCRIP STARTS.####
current_directory = os.getcwd()
metaData_directory = os.path.join(current_directory, "Sub_Applications/Listing_Metadata_Extractor/Image_Output_Directory/")
###PATCH INITIALIZATION END###

i = 0
duplicateID = 1
duplicateDetected = False
runningNewFileRoster = [] #File roster used to keep track of potential file duplicates...
#function definitions
def getImageDescription(path, file_Array):
	"""Detects web annotations given an image."""
	
	tempString = "Test string."
	finalizedString = "NO_MATCH_FOUND"
	tempStringLength = 0
	
	client = vision.ImageAnnotatorClient()

	with open(path, "rb") as image_file:
		content = image_file.read()

	image = vision.Image(content=content)

	response = client.web_detection(image=image)
	annotations = response.web_detection

	if annotations.web_entities: #look for web entity with the longest description. Then, it will return it back as the finalizedString variable.
		for entity in annotations.web_entities:
			tempString = str(entity.description)
			if len(tempString) > tempStringLength:
				tempStringLength = len(tempString)
				finalizedString = tempString
				
	if response.error.message:
		raise Exception(
			'{}\nFor more info on error messages, check: '
			'https://cloud.google.com/apis/design/errors'.format(
				response.error.message))
		input('Error! An exception occurred during the Google Vision file renamer program runtime. Exception: ' + str(format(response.error.message)))
		
	finalizedString = finalizedString.replace(" ", "_") #replacing all file name spaces with underscores to help prevent issues with file creation
	finalizedString = finalizedString.replace("/", "SLASH") #replacing all file name forward slashes with word to help prevent issues with file creation
	finalizedString = finalizedString.replace("\\", "SLASH") #replacing all file name back slashes with word to help prevent issues with file creation
	finalizedString = finalizedString.replace('"','') #removing all other special characters considered bad practice/dangerous for file naming...
	finalizedString = finalizedString.replace("'", "") 
	finalizedString = finalizedString.replace(":", "")
	finalizedString = finalizedString.replace(";", "")  
	finalizedString = finalizedString.replace("#", "")  
	finalizedString = finalizedString.replace("%", "")  
	finalizedString = finalizedString.replace("&", "")  
	finalizedString = finalizedString.replace("}", "")  
	finalizedString = finalizedString.replace("{", "")  
	finalizedString = finalizedString.replace("<", "")  
	finalizedString = finalizedString.replace(">", "")  
	finalizedString = finalizedString.replace("*", "")  
	finalizedString = finalizedString.replace("?", "")  
	finalizedString = finalizedString.replace("$", "")  
	finalizedString = finalizedString.replace("!", "")  
	finalizedString = finalizedString.replace("+", "")  
	finalizedString = finalizedString.replace("`", "")  
	finalizedString = finalizedString.replace("|", "")  
	finalizedString = finalizedString.replace("=", "")  
	
	last_period_index = finalizedString.rfind('.') #looking for any last occurrences of a period character, to prevent double periods occurring at the file extension...
	
	if last_period_index == len(finalizedString) - 1: #if the period exists ONLY at the very end...
		finalizedString = finalizedString[:-1] #then remove last character, which can only be a period in this case...
			
	finalizedString = finalizedString.title() #cleaning up caps locked words and all lowercase words so that only the first letter in each word is capitalized. Cleans up most listing titles reasonably...
	
	if finalizedString in file_Array: #Double-checking to make sure Google Vision didn't actually return a duplicate title in this iteration. If so, it will return the same title but with the string "CPY" followed by a random character string.
		charDUPLICATE = string.ascii_uppercase + string.digits
		duplicateID = ''.join(random.choice(charDUPLICATE) for _ in range(5))
		finalizedString = finalizedString + 'CPY' + duplicateID
		file_Array.append(finalizedString)
	else:
		file_Array.append(finalizedString)
	
	return finalizedString, file_Array #return final description back to whoever called it

def saveImage(filePath, fileName, historyLineNumber):
	tempFileExtension = "FILLER"
	tempFileExtension = os.path.splitext(str(filePath))[-1].lower() #getting file extension so that it can be explicitly added on the filename later...
	fileName = fileName + str(tempFileExtension)
	img = Image.open(filePath)
	if "exif" in img.info: #checking for exif data to see if it needs to be preserved at save or not. The color adjuster, for example, strips all EXIF data which would otherwise cause runtime issues without the conditional statement.
		if(tempFileExtension == '.PNG' or tempFileExtension == '.png'):
			img.save(output_data_folder / fileName,"PNG",exif=img.info.get('exif'))
		if(tempFileExtension == '.jpg' or tempFileExtension == '.JPG' or tempFileExtension == '.jpeg' or tempFileExtension == '.JPEG'): #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
			img.save(output_data_folder / fileName,"JPEG",exif=img.info.get('exif'))
	else:
		if(tempFileExtension == '.PNG' or tempFileExtension == '.png'):
			img.save(output_data_folder / fileName,"PNG")
		if(tempFileExtension == '.jpg' or tempFileExtension == '.JPG' or tempFileExtension == '.jpeg' or tempFileExtension == '.JPEG'): #be sure to save the file in appropriate format internally depending on if it is a JPEG or PNG image file type.
			img.save(output_data_folder / fileName,"JPEG")
		
	print(fileName + ' saved.')
	
	######
	baseOutputFile = str(fileName) #generating the outputted file name so that it can be recorded into the file history text file...
	fileHistoryOutputFile(baseOutputFile, historyLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
	######
	
def fixMetadataFile(old_name, new_name): ###PATCH: Corrects Potentially Mismatching Meta Text File Names and brings them up to their updated Google Vision AI retitled name.
	print('Fixing METADATA file from ' + old_name + '.txt to ' + new_name + '_metadata' + '.txt...')
	current_file_path = os.path.join(metaData_directory, str(old_name + '_metadata' + '.txt')) #old metadata file name
	new_file_path = os.path.join(metaData_directory, str(new_name + '_metadata' + '.txt')) #new metadata file name
	#print('Current File Path: ' + current_file_path)
	#print('New File Path: ' + new_file_path)
	os.rename(current_file_path, new_file_path)
		
def returnUpdatedName(filePath, fileArray):
	fileName = "TEMP"
	fileName, fileArray = getImageDescription(filePath, fileArray) #get item description/title for that specific image file in each iteration	
	return fileName, fileArray

######
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {AIRENAMED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
######

#function definitions

#imperative commands#
print('Starting Google Vision AI Listing Image Renamer...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #begin Google Lens folder naming generation here
	currentFilePath = input_data_folder / filesList[i] #adjusting source image filename for each iteration
	
	######
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	######
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	oldFileName = str(Path(currentFilePath).stem) ###PATCH: Old file name will be used to reference appropriate metadata file when the text file in question's file name is revised for usage by the consolidator.###
	saveName = "TEMP"
	saveName, runningNewFileRoster = returnUpdatedName(currentFilePath, runningNewFileRoster)
	saveImage(currentFilePath, saveName, fileHistoryTextLineNumber) #call image saving process - it also calls getImageDescription in each instance as well.
	
	line = linecache.getline(str(configFile), 7) #getting metadata setting from configuration file... in this case it should always be from line 7...
	line = line.strip()
	if line == "generateMetadata=YES":
		fixMetadataFile(oldFileName, saveName) ###PATCH### calling metadata file fix if the configuration file is allowing for such a process to take place.
		
	i = i + 1

#input("Process completed. You may close the terminal window now.")
#imperative commands#


