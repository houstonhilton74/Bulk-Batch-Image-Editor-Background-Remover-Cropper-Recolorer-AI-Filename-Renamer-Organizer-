import requests
import json
import base64
###Update Open Auth Token Every Now and Then!###

# Replace with your eBay API credentials
api_endpoint = 'https://api.ebay.com/buy/browse/v1/item_summary/search_by_image'
# Encode your image file as base64
with open('testimage.jpg', 'rb') as image_file:
	image_base64 = base64.b64encode(image_file.read()).decode()
	image_base64 = str(image_base64) #forcing source image to be a string of Base64 code.
print('Decode64 Result: ' + image_base64)

#headers = {"Authorization": "bearer ",
headers = {"Authorization": "bearer v^1.1#i^1#f^0#I^3#r^0#p^3#t^H4sIAAAAAAAAAOVZa2wcRx332U6a0JpIkDbQVO3lAk2Lu3ezu3f7Su7Q2XfGV78uPjshhmLN7c7eTby3u96ZtX0WMY4FVkvVVkj0gVBaF6kqRQqQFkiEC1IR7YdW5QMvCb5UopQipQgqFUV8QcyeH7mYNol9Rj2J9YfTzvxfv//TMwvmd+7+zGLv4qWO0A2tS/NgvjUU4m8Eu3fu6PxoW+utO1pAHUFoaf5T8+0LbX89QmDFcrVhRFzHJig8U7FsotUWkxHfszUHEkw0G1YQ0aiuFdID/ZoQBZrrOdTRHSsSzmWSEcWUE4akoDhfNERZENmqvSZzxElGeB3okhCHusx2oSKzfUJ8lLMJhTZNRgQgiBxQOV4c4WVNUDTAdABhLBI+hjyCHZuRREEkVTNXq/F6dbZe3VRICPIoExJJ5dI9haF0LpMdHDkSq5OVWvVDgULqkyvfuh0DhY9By0dXV0Nq1FrB13VESCSWWtFwpVAtvWbMFsyvudpIAEMUYUJJgAQQ42BbXNnjeBVIr25HsIINzqyRasimmFav5VHmjeJJpNPVt0EmIpcJBz9HfWhhEyMvGcl2pU+MFrLDkXAhn/ecKWwgI0DKA1WQxIQaFyIp6BUdj5Qdd1XJiqRVF2/Q0u3YBg4cRsKDDu1CzGK00S98nV8Y0ZA95KVNGlhTT6fW/MdHVVUdCwK6EkGflu0gpqjCnBCuvV7b+2vpcDkBtisheEmBCQAlXS4qRQDfPx+CWt9cTqSCsKTz+VhgCirCKleB3gSirgV1xOnMu34FedjQxIQpiIqJOENSTS6umiZXZM2A402EAELFoq4q/y+pQamHiz5F6+mxcaMGMBkp6I6L8o6F9WpkI0mt1awmwwxJRsqUulosNj09HZ0Wo45XigkA8LHPD/QX9DKqsICv0eJrE3O4lhc6YlwEa7TqMmtmWNYx5XYpkhI9Iw89Wi0gy2ILazl7hW2pjasfALLbwswDI0xFc2HsdQhFRkPQDDSFdTSOjeZCJvASmwtBrQuqIDPWhkBaTgnbA4iWnSaDmR1I5/obgsbaJ6TNBaq+uYBaE2LNBUgckDUAGgKbdt1cpeJTWLRQrslCGVeEuNRYmrq+32x1WCj3jU0OFPtGjqGGoAVjV8PQ1Kgzgez366RBrX+4WIezPcPZQu/4yFBfdrAhtMPI9BApjwRYmy1P00fTuTR7BvLYPDHFD3+O9HRmjZ4J82Sngodds5CQR6V8zkB90/fCjNs5MTk4li4VRuW+4ydm+5zRhC2OlaRKPnM0mWzISQWke6jJWle6+0S/nMnMCrArIx4X490JY3rU6x4Yoa55dCZTlJVyuccReu30dGPgB0rNVukrE3c7pu3IB5X4OsCg1j8UkN5KYY7XutA4e2sIaLbUdP1aMaW4hPgir0DA/iQoqJLEC6LJHlXVEw2P3ybD2+v4hDp2L1eEVC9bmHD54Qw7v8kJkxcVwIG4GOeNBGxwLjdbmLdrLJPg9Pa/hRbU+mbhBTIIEwJdHA3+c4jqTiXmQJ+Wg6XxmtXh6yGKEXb6i64c95nkqIeg4dhWdSvMm+DB9hQ7LzpedSsK15k3wQN13fFtuhV1q6yb4DB9y8SWFVwKbEVhHftmzLShVaVYJ1tSie0g28gmWFxYrQE0MHGDerkuTrZWQZ6OothYuVXcpLHr/LZDsYl1GFzwRIlfJLqH3drV2jbJWTesscMnMrCHdDruezjoIqzWX2yeJrk6G8Z7sRX8cBtmBTdZtarubEMOCPzejPcK+XShcHxoONMQuAyaarZxr8ogARWAOEMUJS5uQMgVQRxxomhCHgAlLvJyQ5ib7jKFl9S4JEhAVq8X14aFugvc/7q2j135zSzVUnv4hdAvwELo562hEDgCPs0fBAd2to22t910K8GU9TZoRgku2ZD6HopOoKoLsdf68ZZL4O1v6+/0Pvf1iX9PT/7l8KmW+k92S/eBT6x/tNvdxt9Y9wUP3HZ5Zwe/Z1+HIAKVZ5EUFCCMgYOXd9v5W9r3fvItMnvgppd33b18x4NdnUuLu5/64g9BxzpRKLSjpX0h1HLyvjMfmXtEGHz9Vftm7om0dP7cQPu50ON3xr7V+cThc+d/yl144/F9C+1PPn/DsaXT3NPxA3u9l478ZvzOt/KL5RcO3V3q+cofu07/Ovzaz84spsi0fPuunjtevfjd7z3/0BeMxz72pa8Ndd+zfzn9jDz7598q2bseOt8TOj35hz17vvrML+cmLyzvm3z396+8AhOHrBdn9j/88v6/3X/2nQsLtxmHu9/80zdmv/OP73OJeyefXVZO3T5nZn/U8cau8//68sHO99rOngup96Af/OSg8vdbHn3ukZdK+tlDDyw9den0gY7lp+WJm388//p7ydce/ubF/vtLb+4d+6fn/m7+2a5TZ/IPlqbefvKFuwqfnfvVxbnozgvvJlZi+R+28dmbTB0AAA==",
	"Content-Type":"application/json",
	"Accept":"application/json",
	"Content-Language":"en-US"}

# Create the request data
request_data = {
	"image":image_base64,
}

# Send the API request
response = requests.post(api_endpoint, headers=headers, json=request_data )

#out_file = open("JSONtest.json", "w") #json file generator... for testing purposes only...
#json.dump(response.json(), out_file, indent = 6)
#out_file.close() 

print("Status Code: ", response.status_code)
print("JSON Response: ", response.json())
titleValue = response.json()['itemSummaries'][0]['title'] #getting first title string from the full local JSON delivery, which is usually the most relevant...
print('First Title Found: ' + str(titleValue))