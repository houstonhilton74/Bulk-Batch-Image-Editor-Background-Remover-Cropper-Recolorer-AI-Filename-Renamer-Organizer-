#programmer reference#
#This program cross references between the main program's input directory used during the AI image identification and folder creation process and the "full image lot" folder
#that includes all in-between images not used during the image identification and folder creation process. This occurs AFTER the consolidation and file copying BACK to the main output folder occurs.
#programmer reference#

#importing libraries and so forth#
import os
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
import shutil
#importing libraries and so forth#

#variable initializations#
main_input_folder = Path(__file__).parent.parent.parent / "./Master_Input_Folder/"
main_output_folder = Path(__file__).parent.parent.parent / "./Master_Output_Folder/"
full_image_lot = Path(__file__).parent.parent.parent / "./Full_Image_Lot_Optional/"
mainInputArray = [] #array to keep track of main input's file names as a sorted "roster."
fullLotFileArray = [] #array to keep track of full image lot's file names as a sorted "roster."
i = 0 #generic iterator
#variable initializations#


#function definitions

def build_base_roster(folder_path): #lists files and their extensions in any given folder to an array...
	files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
	sorted_files = sorted(files)
	tempArray = []
	for file_name in sorted_files:
		tempFileNameString = "DUMMY"
		tempFileNameString = str(file_name)
		tempArray.append(tempFileNameString) #adding sorted file name file-by-file, sorted, to the appropriate array/roster/list.
	return tempArray

def getAndCopyInBetweenFiles(input_array, full_lot_array): #gets potential array "boundaries" where any in-between image files could exist and copy them accordingly. This is the main chunk of the program.
	i = 0
	while i < len(input_array):
		if input_array[i] in full_lot_array: #####PATCH#####checking to ensure that the starting file boundary for each iteration exists in the full image lot array... in case the user forgets to copy over a few AI-friendly images into the full image listing folder.
			frontBoundaryFile = input_array[i] #getting front boundary file to be used in checking the full image lot roster later... everything after that AND right before the next item in the input array
			if i >= len(input_array) - 1: #creating exception for last file in input file array. Any file(s) after that file in the full lot roster will automatically be copied if present.
				backBoundaryFile = "LAST_INPUT_FILE_EXCEPTION" #getting ending boundary file. This is the file where the in-between files should stop at right before.
			else:
				backBoundaryFile = input_array[i + 1]
		
			if backBoundaryFile in full_lot_array or backBoundaryFile == "LAST_INPUT_FILE_EXCEPTION": #####PATCH##### Checking to see if there is a definitive ending point file or end of array exception for the in-between files in the full image lot array...
				fullListFrontIndex = full_lot_array.index(frontBoundaryFile)
				if backBoundaryFile != "LAST_INPUT_FILE_EXCEPTION":
					fullListBackIndex = full_lot_array.index(backBoundaryFile) #getting corresponding indicies for the front and back boundary files from full lot array... This defines, in array terms, where in the full lot array to look for in-betweens.
				else:
					fullListBackIndex = len(full_lot_array) - 1 #set back boundary file index to last possible index in full lot array if the last input file in input array is being used.
		
				fullListFrontIndex = fullListFrontIndex + 1 #offsetting front for upcoming segment generation...
		
				currentInBetweenSegment = full_lot_array[fullListFrontIndex:fullListBackIndex] #generating in-between array segment from full list based on calculated front and back boundaries mentioned previously...
		
				if backBoundaryFile == "LAST_INPUT_FILE_EXCEPTION": #make an exception execution that adds last possible full image list file names to last generated array segment as appropriate...
					if full_lot_array.index(frontBoundaryFile) + 1 == len(full_lot_array): #if remaining front boundary file index matches the length of the whole array, it can be assumed that the array segment is [], as it's also the end of the full file array.
						currentInBetweenSegment = []
					if len(full_lot_array) > full_lot_array.index(frontBoundaryFile) + 1: #for any amount of full list items remaining that is greater than 0...
						leftoversSize = full_lot_array.index(frontBoundaryFile) + 1 - len(full_lot_array) #find the number of "leftover" full list items, counting from the frontBoundaryFile, non-inclusive.
						#input("Leftovers Size: " + str(leftoversSize) + ". Press Enter to continue.")
						currentInBetweenSegment = full_lot_array[leftoversSize:] #slice full lot array, working backwards, at the size of the calculated "leftover" full list file items.
		
				if len(currentInBetweenSegment) == 0: #preparing actual copying. This system will not copy files if any subsegment does not have any relevant in-between files...
					print('No relevant in-between files detected for file ' + str(input_array[i]) + '. Continuing on to next file if applicable...')
				else:
					print('Copying in-between file(s) for file ' + str(input_array[i] + '...'))
					for root, dirs, files in os.walk(main_output_folder): #getting location of file in input_array in main output folder so that we know where we're copying the files to...
						if input_array[i] in files:
							currentFileCopyPath = os.path.dirname(os.path.join(root, input_array[i]))
			
					for file_name in currentInBetweenSegment: #creating for loop that copies each file in current in-between file array segment to the main output folder...
						source_path = os.path.join(full_image_lot, file_name)
						destination_path = os.path.join(currentFileCopyPath, file_name)
						shutil.copy2(source_path, destination_path)
						print('Copy of an in-between file for ' + input_array[i] + ' successful.')
			else:
				print('Warning: No endpoint boundary was able to be successfully defined for any potential in-between files for file ' + input_array[i] + ' in the full image lot folder. Any relevant in-between images will not be copied. Skipping to next AI-friendly image if applicable...')

		else:
			print('Warning: Corresponding AI input file '+ input_array[i] + ' used for defining starting in-between image(s) boundary was not found in the full image lot folder. Any relevant in-between images will not be copied. Skipping to next AI-friendly image if applicable...')
			
		i = i + 1
	
	
#function definitions

#imperative commands#
print('Processing and consolidating in-between images that were not used originally to create folders or for AI product identification purposes...')

print('Building input image file roster...')
mainInputArray = build_base_roster(main_input_folder)

print('Building full lot image file roster...')
fullLotFileArray = build_base_roster(full_image_lot)

print('Getting in-between full file array rosters if applicable and copying them accordingly...')
getAndCopyInBetweenFiles(mainInputArray, fullLotFileArray)

#input("Press Enter to continue.")
#imperative commands#


