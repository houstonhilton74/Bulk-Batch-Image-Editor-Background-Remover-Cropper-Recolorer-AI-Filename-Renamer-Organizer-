#programmer reference#

#programmer reference#

#importing libraries and so forth#
import numpy as np
from PIL import Image
from pathlib import Path
import os, os.path
from os import listdir
from os.path import isfile, join
from os.path import exists
from google.cloud import vision
import io
import re
import linecache

#importing libraries and so forth#

#variable initializations#
output_data_folder = Path(__file__).parent / "./Image_Output_Directory/"
input_data_folder = Path(__file__).parent / "./Image_Input_Directory/"
currentFilePath = input_data_folder / "test.jpg"
######
fileHistoryFileFullPath = Path(__file__).parent.parent.parent / "FileHistory.txt"
######
i = 0
rawTextString = " " #unprocessed text string generated from first OCR check of image with Google API
itemDescription = "FILL ME IN"
itemPrice = "FILL ME IN"
itemDimensions = "FILL ME IN"
itemWeight = "FILL ME IN"
#function definitions

def get_raw_text_string_from_image(path):
	"""Detects document features in an image."""
	tempString = " " #initiating temporary string
	client = vision.ImageAnnotatorClient()

	# [START vision_python_migration_document_text_detection]
	with io.open(path, 'rb') as image_file:
		content = image_file.read()

	image = vision.Image(content=content)

	response = client.document_text_detection(image=image, image_context={"language_hints": ["en"]},)

	for page in response.full_text_annotation.pages:
		for block in page.blocks:
			
			for paragraph in block.paragraphs:
				for word in paragraph.words:
					word_text = ''.join([
						symbol.text for symbol in word.symbols
					])
					tempString = tempString + str(word_text) #string adds up all detected characters. The semicolon is the assumed separater for future processing.

	return tempString
	
	if response.error.message:
		raise Exception(
			'{}\nFor more info on error messages, check: '
			'https://cloud.google.com/apis/design/errors'.format(
				response.error.message))
		input('Error! An exception occurred during the Google Vision file renamer program runtime. Exception: ' + str(format(response.error.message)))

def search(stringList, queryVariant1, queryVariant2,queryVariant3, queryVariant4, queryVariant5, queryVariant6, queryVariant7, queryVariant8, queryVariant9, queryVariant10, queryVariant11, queryVariant12): #algorithm to find first item in list containing a specific character relevant to each anticipated metadata type.
	for s in stringList:
		if queryVariant1 in s:
			return str(s)
		if queryVariant2 in s:
			return str(s)
		if queryVariant3 in s:
			return str(s)
		if queryVariant4 in s:
			return str(s)
		if queryVariant5 in s:
			return str(s)
		if queryVariant6 in s:
			return str(s)
		if queryVariant7 in s:
			return str(s)
		if queryVariant8 in s:
			return str(s)
		if queryVariant9 in s:
			return str(s)
		if queryVariant10 in s:
			return str(s)
		if queryVariant11 in s:
			return str(s)
		if queryVariant12 in s:
			return str(s)
		
	return "NOTHING FOUND!"

def processRawText(raw_text):
	fixedText = "blah"
	fixedText = raw_text
	fixedText = raw_text.replace(';', '', 1) #removing first semicolon in raw text string
	tempArr = []
	tempArr = re.split(';', fixedText) #converting cleaned up text into a temporary array to be accessed directly later.
	tempDescription = "Description_FILLER"
	tempDescription = tempArr[0] #Sets description as first item in array. The description should always be the first and top most item whenever creating photos.
	#print('Item Specifics/Description: ' + tempDescription)
	del tempArr[0] #get rid of description part of array, as the rest of the algorithm looks for specific characters to help identify items.
	tempPriceString = "$1,000,000,000.00" # setting up variables to be used as parsed storage spaces for listing data as well as location data where they are in the raw text string by counting the number of semicolons
	tempDimensionsString = "NO_DIMENSIONS"
	tempWeightString = "0 Pounds 0 Ounces"
	#print(tempArr)
	tempPriceString = search(tempArr, "$", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}") #set temporary listing values to what can be found. Otherwise, they will default to obscene numbers on purpose. Braces were used because they should not be on image.
	#print('Item Price: ' + tempPriceString)
	tempDimensionsString = search(tempArr, "x", "X", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}")
	#print('Item Dimensions: ' + tempDimensionsString)
	tempWeightString = search(tempArr, "lb", "LB", "Lb", "Pound", "pound", "POUND", "Ounce", "OUNCE", "ounce", "OZ", "Oz", "oz")
	#print('Item Weight: ' + tempWeightString)

	return tempDescription, tempPriceString, tempDimensionsString, tempWeightString	#return data back from when it was called. It'll likely be ported over to the save to text file function eventually.

def saveDataToFile(currentFile, description, price, dimensions, weight, historyLineNumber):
	print('Currently Processing Image File: ' + str(os.path.basename(currentFile)))
	print('Item Save Description: ' + description)
	print('Item Save Price: ' + price)
	print('Item Save Dimensions: ' + dimensions)
	print('Item Save Weight: ' + weight)
	fileName = "File Name Placeholder for Saver"
	fileName = str(os.path.splitext(currentFile)[0]) + "_metadata" #gets rid of old image file extension in file title in preparation for saving text file...
	fileName = str(os.path.basename(fileName))
	completeName = os.path.join(output_data_folder, fileName +".txt") #generating appropriate text file save path...
	file = open(completeName, "w") #creating new text file with file name and regular save location
	file.write("Old_File_Name: " + str(os.path.basename(currentFile)) + "\n") #adding old file name in text file for reference later when copying the old file back into the 
	file.write("Description: "+ description + "\n")
	file.write("Price: " + price + "\n")
	file.write("Dimensions: " + dimensions + "\n")
	file.write("Weight: " + weight) #writing in data lines into text file...
	file.close()
	
	print('Saved as: ' + fileName + '.txt')
	
	######
	baseOutputFile = str(fileName + ".txt") #generating the outputted file name so that it can be recorded into the file history text file...
	fileHistoryOutputFile(baseOutputFile, historyLineNumber) #actual call of function that writes out the outputted file name and its extension to the given line number.
	######
	
######
def fileHistoryInputFile(file_search_key): ###This function is intended for future listing organization/consolidation purposes. What it does is file any matching file name in the sub application's local input folder and its extension into a single line to keep a written history of how a file was processed. If no history is found, it generates a new history "string" in a new line.
	lookup = str(file_search_key) + "\n"
	
	with open(fileHistoryFileFullPath) as myFile:
		for num, line in enumerate(myFile, 1):
			if lookup in line:
				#input(str(file_search_key) + ' found at line:' + str(num))
				myFile.close()
				return num
			else:
				with open(fileHistoryFileFullPath, 'a') as file: #if equivalent text string history for the requested image file was not found, append a new text line with the file name in the next text line. This occurs if this specific sub application call happens to be "first in line" in the user's set running configuration. It then returns the line number by searching for it again with a guaranteed success.
					file.write(file_search_key + '\n')
					file.close()
				lookup = str(file_search_key) + "\n"
				
				with open(fileHistoryFileFullPath) as myFile: #then re-read the file to figure out where the new line number is after the new file history line was appended to the file history text file... 
					for num, line in enumerate(myFile, 1):
						if lookup in line:
							#input(str(file_search_key) + ' found at line:' + str(num))
							myFile.close()
							return num
	
def fileHistoryOutputFile(output_File, line_Number): #This is for the second call of the fileHistory program. It does not need to search for the line number of the inputted file, as that was already returned by the equivalent input file version of the program. All it does is write the given outputted file name at the end of the line using the line number where the equivalent input file was previously detected.
	tempfileHistoryLine = linecache.checkcache(str(fileHistoryFileFullPath))
	tempfileHistoryLine = linecache.getline(str(fileHistoryFileFullPath), line_Number)
	tempfileHistoryLine = tempfileHistoryLine.strip()
	tempfileHistoryLine = "\n" + tempfileHistoryLine + " -> {METADATAEXTRACTED}" + str(output_File) + "\n" #adding this sub program's outputted file name into the appropriate given line number of file history text file...
	#input("TEMP file History Line Process 2, For Line Number " + str(line_Number) + " " + str(tempfileHistoryLine) + " with output file " + str(output_File))
	
	with open(fileHistoryFileFullPath, "r") as file:
		lines = file.readlines()
		file.close()
	lines[line_Number - 1] = tempfileHistoryLine #0 indexed, just to make things tricky...
	with open(fileHistoryFileFullPath, "w") as file:
		file.writelines(lines)	
		file.close()
######
#function definitions

#imperative commands#
print('Starting listing metadata extractor...')

_, _, files = next(os.walk(input_data_folder)) #counting files in input folder in preparation for batch run...
file_count = len(files)

i = 0 #setting main iterator to manage what source file you're on in the input directory.

filesList = [f for f in listdir(input_data_folder) if isfile(join(input_data_folder, f))] #parsing file manifest list for input folder

while i < file_count: #counting files to know how many iterations need to occur
	currentFilePath = input_data_folder / filesList[i] #adjusting source image filename for each iteration
	######
	baseName = str(os.path.basename(input_data_folder / filesList[i]))
	######
	
	######
	fileHistoryTextLineNumber = fileHistoryInputFile(baseName) #Writing in history of input folder image file that was processed (if applicable)... also returns the line number that the history of the current equivalent file in the input folder is written at.
	######
	
	rawTextString = get_raw_text_string_from_image(currentFilePath) #get raw text string from each image file
	#print('Raw Text: ' + rawTextString)
	itemDescription, itemPrice, itemDimensions, itemWeight = processRawText(rawTextString) #process raw text generated by Google API and collect what is returned in each respective variable to be then passed as arguments to a save file function
	saveDataToFile(currentFilePath, itemDescription, itemPrice, itemDimensions, itemWeight, fileHistoryTextLineNumber) #Actual file saving per file happens with this function
	i = i + 1
	
#input("Process completed. You may close the terminal window now.")
#imperative commands#


